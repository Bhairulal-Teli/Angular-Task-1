import { Bt as computed, Dc as Injector, Ec as InjectionToken, El as ɵɵdefineInjectable, En as ElementRef, Fn as Injectable, Gt as resource, I as debounced, In as Input, Kt as setInParamsFunction, L as declareExperimentalWebMcpTool, Oo as ɵɵgetInheritedFactory, T as afterRenderEffect, Uc as RuntimeError, Ut as isInParamsFunction, Wi as setClassMetadata, Wt as linkedSignal, X as input, Yo as ɵɵlistener, aa as ɵɵControlFeature, fc as CSP_NONCE, hc as DestroyRef, ir as Renderer2, mc as DOCUMENT, nl as formatRuntimeError, no as ɵɵdefineDirective, pl as makeEnvironmentProviders, qt as untracked, rl as forwardRef, sl as inject, tl as effect, ua as ɵɵProvidersFeature, uc as APP_ID, wn as Directive, xl as signal, yi as isPromise, yl as runInInjectionContext, zl as SIGNAL, zt as chain } from "./core-clzGvzSz.js";
import { n as httpResource } from "./http-DXsUjmgh.js";
import { AbstractControl, NG_VALIDATORS, NG_VALUE_ACCESSOR, NgControl, Validators, ɵFORM_CONTROL_INTEGRATION, ɵelementAcceptsMinMax as elementAcceptsMinMax, ɵisNativeFormElement as isNativeFormElement, ɵisTextualFormElement as isTextualFormElement, ɵselectValueAccessor as selectValueAccessor, ɵsetNativeDomProperty as setNativeDomProperty } from "./@angular_forms.js";
//#region node_modules/@angular/forms/fesm2022/_validation_errors-chunk.mjs
/**
* @license Angular v22.1.7
* (c) 2010-2026 Google LLC. https://angular.dev/
* License: MIT
*/
var FIELD_TREE = /* @__PURE__ */ Symbol("FIELD_TREE");
var boundPathDepth = 0;
function getBoundPathDepth() {
	return boundPathDepth;
}
function setBoundPathDepthForResolution(fn, depth) {
	return (...args) => {
		try {
			boundPathDepth = depth;
			return fn(...args);
		} finally {
			boundPathDepth = 0;
		}
	};
}
function shortCircuitFalse(value) {
	return !value;
}
function shortCircuitTrue(value) {
	return value;
}
function isArray(value) {
	return Array.isArray(value);
}
function isObject(value) {
	return (typeof value === "object" || typeof value === "function") && value != null;
}
var DYNAMIC = Symbol();
var IGNORED = Symbol();
var AbstractLogic = class {
	predicates;
	fns = [];
	constructor(predicates) {
		this.predicates = predicates;
	}
	push(logicFn) {
		this.fns.push(wrapWithPredicates(this.predicates, logicFn));
	}
	mergeIn(other) {
		const fns = this.predicates ? other.fns.map((fn) => wrapWithPredicates(this.predicates, fn)) : other.fns;
		this.fns.push(...fns);
	}
	hasRules() {
		return this.fns.length > 0;
	}
};
var BooleanOrLogic = class extends AbstractLogic {
	get defaultValue() {
		return false;
	}
	compute(arg) {
		return this.fns.some((f) => {
			const result = f(arg);
			return result && result !== IGNORED;
		});
	}
};
var ArrayMergeIgnoreLogic = class ArrayMergeIgnoreLogic extends AbstractLogic {
	ignore;
	static ignoreNull(predicates) {
		return new ArrayMergeIgnoreLogic(predicates, (e) => e === null);
	}
	constructor(predicates, ignore) {
		super(predicates);
		this.ignore = ignore;
	}
	get defaultValue() {
		return [];
	}
	compute(arg) {
		return this.fns.reduce((prev, f) => {
			const value = f(arg);
			if (value === void 0 || value === IGNORED) return prev;
			else if (isArray(value)) return [...prev, ...this.ignore ? value.filter((e) => !this.ignore(e)) : value];
			else {
				if (this.ignore && this.ignore(value)) return prev;
				return [...prev, value];
			}
		}, []);
	}
};
var ArrayMergeLogic = class extends ArrayMergeIgnoreLogic {
	constructor(predicates) {
		super(predicates, void 0);
	}
};
var MetadataMergeLogic = class extends AbstractLogic {
	key;
	get defaultValue() {
		return this.key.reducer.getInitial();
	}
	constructor(predicates, key) {
		super(predicates);
		this.key = key;
	}
	compute(ctx) {
		if (this.fns.length === 0) return this.key.reducer.getInitial();
		let acc = this.key.reducer.getInitial();
		for (let i = 0; i < this.fns.length; i++) {
			const item = this.fns[i](ctx);
			if (item !== IGNORED) acc = this.key.reducer.reduce(acc, item);
		}
		return acc;
	}
};
function wrapWithPredicates(predicates, logicFn) {
	if (predicates.length === 0) return logicFn;
	return (arg) => {
		for (const predicate of predicates) {
			let predicateField = arg.stateOf(predicate.path);
			const depthDiff = untracked(predicateField.structure.pathKeys).length - predicate.depth;
			for (let i = 0; i < depthDiff; i++) predicateField = predicateField.structure.parent;
			if (!predicate.fn(predicateField.context)) return IGNORED;
		}
		return logicFn(arg);
	};
}
var LogicContainer = class {
	predicates;
	hidden;
	disabledReasons;
	readonly;
	syncErrors;
	syncTreeErrors;
	asyncErrors;
	metadata = /* @__PURE__ */ new Map();
	constructor(predicates) {
		this.predicates = predicates;
		this.hidden = new BooleanOrLogic(predicates);
		this.disabledReasons = new ArrayMergeLogic(predicates);
		this.readonly = new BooleanOrLogic(predicates);
		this.syncErrors = ArrayMergeIgnoreLogic.ignoreNull(predicates);
		this.syncTreeErrors = ArrayMergeIgnoreLogic.ignoreNull(predicates);
		this.asyncErrors = ArrayMergeIgnoreLogic.ignoreNull(predicates);
	}
	hasAnyLogic() {
		return this.hidden.hasRules() || this.disabledReasons.hasRules() || this.readonly.hasRules() || this.syncErrors.hasRules() || this.syncTreeErrors.hasRules() || this.asyncErrors.hasRules() || this.metadata.size > 0;
	}
	hasMetadata(key) {
		return this.metadata.has(key);
	}
	hasMetadataKeys() {
		return this.metadata.size > 0;
	}
	getMetadataKeys() {
		return this.metadata.keys();
	}
	getMetadata(key) {
		if (!this.metadata.has(key)) this.metadata.set(key, new MetadataMergeLogic(this.predicates, key));
		return this.metadata.get(key);
	}
	mergeIn(other) {
		this.hidden.mergeIn(other.hidden);
		this.disabledReasons.mergeIn(other.disabledReasons);
		this.readonly.mergeIn(other.readonly);
		this.syncErrors.mergeIn(other.syncErrors);
		this.syncTreeErrors.mergeIn(other.syncTreeErrors);
		this.asyncErrors.mergeIn(other.asyncErrors);
		for (const key of other.getMetadataKeys()) {
			const metadataLogic = other.metadata.get(key);
			this.getMetadata(key).mergeIn(metadataLogic);
		}
	}
};
var AbstractLogicNodeBuilder = class {
	depth;
	constructor(depth) {
		this.depth = depth;
	}
	build() {
		return new LeafLogicNode(this, [], 0);
	}
};
var LogicNodeBuilder = class LogicNodeBuilder extends AbstractLogicNodeBuilder {
	constructor(depth) {
		super(depth);
	}
	current;
	all = [];
	addHiddenRule(logic) {
		this.getCurrent().addHiddenRule(logic);
	}
	addDisabledReasonRule(logic) {
		this.getCurrent().addDisabledReasonRule(logic);
	}
	addReadonlyRule(logic) {
		this.getCurrent().addReadonlyRule(logic);
	}
	addSyncErrorRule(logic) {
		this.getCurrent().addSyncErrorRule(logic);
	}
	addSyncTreeErrorRule(logic) {
		this.getCurrent().addSyncTreeErrorRule(logic);
	}
	addAsyncErrorRule(logic) {
		this.getCurrent().addAsyncErrorRule(logic);
	}
	addMetadataRule(key, logic) {
		this.getCurrent().addMetadataRule(key, logic);
	}
	getChild(key) {
		if (key === DYNAMIC) {
			const children = this.getCurrent().children;
			if (children.size > (children.has(DYNAMIC) ? 1 : 0)) this.current = void 0;
		}
		return this.getCurrent().getChild(key);
	}
	hasLogic(builder) {
		if (this === builder) return true;
		return this.all.some(({ builder: subBuilder }) => subBuilder.hasLogic(builder));
	}
	hasRules() {
		return this.all.length > 0;
	}
	anyChildHasLogic() {
		return this.all.some(({ builder }) => builder.anyChildHasLogic());
	}
	mergeIn(other, predicate) {
		if (predicate) this.all.push({
			builder: other,
			predicate: {
				fn: setBoundPathDepthForResolution(predicate.fn, this.depth),
				path: predicate.path
			}
		});
		else this.all.push({ builder: other });
		this.current = void 0;
	}
	getCurrent() {
		if (this.current === void 0) {
			this.current = new NonMergeableLogicNodeBuilder(this.depth);
			this.all.push({ builder: this.current });
		}
		return this.current;
	}
	static newRoot() {
		return new LogicNodeBuilder(0);
	}
};
var NonMergeableLogicNodeBuilder = class extends AbstractLogicNodeBuilder {
	logic = new LogicContainer([]);
	children = /* @__PURE__ */ new Map();
	constructor(depth) {
		super(depth);
	}
	addHiddenRule(logic) {
		this.logic.hidden.push(setBoundPathDepthForResolution(logic, this.depth));
	}
	addDisabledReasonRule(logic) {
		this.logic.disabledReasons.push(setBoundPathDepthForResolution(logic, this.depth));
	}
	addReadonlyRule(logic) {
		this.logic.readonly.push(setBoundPathDepthForResolution(logic, this.depth));
	}
	addSyncErrorRule(logic) {
		this.logic.syncErrors.push(setBoundPathDepthForResolution(logic, this.depth));
	}
	addSyncTreeErrorRule(logic) {
		this.logic.syncTreeErrors.push(setBoundPathDepthForResolution(logic, this.depth));
	}
	addAsyncErrorRule(logic) {
		this.logic.asyncErrors.push(setBoundPathDepthForResolution(logic, this.depth));
	}
	addMetadataRule(key, logic) {
		this.logic.getMetadata(key).push(setBoundPathDepthForResolution(logic, this.depth));
	}
	getChild(key) {
		if (!this.children.has(key)) this.children.set(key, new LogicNodeBuilder(this.depth + 1));
		return this.children.get(key);
	}
	hasLogic(builder) {
		return this === builder;
	}
	hasRules() {
		return this.logic.hasAnyLogic() || this.children.size > 0;
	}
	anyChildHasLogic() {
		for (const child of this.children.values()) if (child.hasRules()) return true;
		return false;
	}
};
var LeafLogicNode = class LeafLogicNode {
	builder;
	predicates;
	depth;
	logic;
	constructor(builder, predicates, depth) {
		this.builder = builder;
		this.predicates = predicates;
		this.depth = depth;
		this.logic = builder ? createLogic(builder, predicates, depth) : new LogicContainer([]);
	}
	getChild(key) {
		const childBuilders = this.builder ? getAllChildBuilders(this.builder, key) : [];
		if (childBuilders.length === 0) return new LeafLogicNode(void 0, [], this.depth + 1);
		else if (childBuilders.length === 1) {
			const { builder, predicates } = childBuilders[0];
			return new LeafLogicNode(builder, [...this.predicates, ...predicates.map((p) => bindLevel(p, this.depth))], this.depth + 1);
		} else return new CompositeLogicNode(childBuilders.map(({ builder, predicates }) => new LeafLogicNode(builder, [...this.predicates, ...predicates.map((p) => bindLevel(p, this.depth))], this.depth + 1)));
	}
	hasLogic(builder) {
		if (!this.builder) return false;
		return this.builder.hasLogic(builder);
	}
	hasRules() {
		return this.builder ? this.builder.hasRules() : false;
	}
	anyChildHasLogic() {
		return this.builder ? this.builder.anyChildHasLogic() : false;
	}
};
var CompositeLogicNode = class CompositeLogicNode {
	all;
	logic;
	constructor(all) {
		this.all = all;
		this.logic = new LogicContainer([]);
		for (const node of all) this.logic.mergeIn(node.logic);
	}
	getChild(key) {
		return new CompositeLogicNode(this.all.flatMap((child) => child.getChild(key)));
	}
	hasLogic(builder) {
		return this.all.some((node) => node.hasLogic(builder));
	}
	hasRules() {
		return this.all.some((node) => node.hasRules());
	}
	anyChildHasLogic() {
		return this.all.some((child) => child.anyChildHasLogic());
	}
};
function getAllChildBuilders(builder, key) {
	if (builder instanceof LogicNodeBuilder) return builder.all.flatMap(({ builder, predicate }) => {
		const children = getAllChildBuilders(builder, key);
		if (predicate) return children.map(({ builder, predicates }) => ({
			builder,
			predicates: [...predicates, predicate]
		}));
		return children;
	});
	else if (builder instanceof NonMergeableLogicNodeBuilder) return [...key !== DYNAMIC && builder.children.has(DYNAMIC) ? [{
		builder: builder.getChild(DYNAMIC),
		predicates: []
	}] : [], ...builder.children.has(key) ? [{
		builder: builder.getChild(key),
		predicates: []
	}] : []];
	else throw new RuntimeError(1909, ngDevMode && "Unknown LogicNodeBuilder type");
}
function createLogic(builder, predicates, depth) {
	const logic = new LogicContainer(predicates);
	if (builder instanceof LogicNodeBuilder) {
		const builtNodes = builder.all.map(({ builder, predicate }) => new LeafLogicNode(builder, predicate ? [...predicates, bindLevel(predicate, depth)] : predicates, depth));
		for (const node of builtNodes) logic.mergeIn(node.logic);
	} else if (builder instanceof NonMergeableLogicNodeBuilder) logic.mergeIn(builder.logic);
	else throw new RuntimeError(1909, ngDevMode && "Unknown LogicNodeBuilder type");
	return logic;
}
function bindLevel(predicate, depth) {
	return {
		...predicate,
		depth
	};
}
var PATH = Symbol("PATH");
var FieldPathNode = class FieldPathNode {
	keys;
	parent;
	keyInParent;
	root;
	children = /* @__PURE__ */ new Map();
	fieldPathProxy = new Proxy(this, FIELD_PATH_PROXY_HANDLER);
	logicBuilder;
	constructor(keys, root, parent, keyInParent) {
		this.keys = keys;
		this.parent = parent;
		this.keyInParent = keyInParent;
		this.root = root ?? this;
		if (!parent) this.logicBuilder = LogicNodeBuilder.newRoot();
	}
	get builder() {
		if (this.logicBuilder) return this.logicBuilder;
		return this.parent.builder.getChild(this.keyInParent);
	}
	getChild(key) {
		if (!this.children.has(key)) this.children.set(key, new FieldPathNode([...this.keys, key], this.root, this, key));
		return this.children.get(key);
	}
	mergeIn(other, predicate) {
		const path = other.compile();
		this.builder.mergeIn(path.builder, predicate);
	}
	static unwrapFieldPath(formPath) {
		return formPath[PATH];
	}
	static newRoot() {
		return new FieldPathNode([], void 0, void 0, void 0);
	}
};
var FIELD_PATH_PROXY_HANDLER = { get(node, property) {
	if (property === PATH) return node;
	return node.getChild(property).fieldPathProxy;
} };
var currentCompilingNode = void 0;
var compiledSchemas = /* @__PURE__ */ new Map();
var SchemaImpl = class SchemaImpl {
	schemaFn;
	constructor(schemaFn) {
		this.schemaFn = schemaFn;
	}
	compile() {
		if (compiledSchemas.has(this)) return compiledSchemas.get(this);
		const path = FieldPathNode.newRoot();
		compiledSchemas.set(this, path);
		let prevCompilingNode = currentCompilingNode;
		try {
			currentCompilingNode = path;
			this.schemaFn(path.fieldPathProxy);
		} finally {
			currentCompilingNode = prevCompilingNode;
		}
		return path;
	}
	static create(schema) {
		if (schema instanceof SchemaImpl) return schema;
		return new SchemaImpl(schema);
	}
	static rootCompile(schema) {
		try {
			compiledSchemas.clear();
			if (schema === void 0) return FieldPathNode.newRoot();
			if (schema instanceof SchemaImpl) return schema.compile();
			return new SchemaImpl(schema).compile();
		} finally {
			compiledSchemas.clear();
		}
	}
};
function isSchemaOrSchemaFn(value) {
	return value instanceof SchemaImpl || typeof value === "function";
}
function assertPathIsCurrent(path) {
	if (currentCompilingNode !== FieldPathNode.unwrapFieldPath(path).root) throw new RuntimeError(1908, ngDevMode && `A FieldPath can only be used directly within the Schema that owns it, **not** outside of it or within a sub-schema.`);
}
function metadata(path, key, logic) {
	assertPathIsCurrent(path);
	FieldPathNode.unwrapFieldPath(path).builder.addMetadataRule(key, logic);
	return key;
}
var MetadataReducer = {
	list() {
		return {
			reduce: (acc, item) => item === void 0 ? acc : [...acc, item],
			getInitial: () => []
		};
	},
	min() {
		return {
			reduce: (acc, item) => {
				if (acc === void 0 || item === void 0) return acc ?? item;
				return item < acc ? item : acc;
			},
			getInitial: () => void 0
		};
	},
	max() {
		return {
			reduce: (acc, item) => {
				if (acc === void 0 || item === void 0) return acc ?? item;
				return item > acc ? item : acc;
			},
			getInitial: () => void 0
		};
	},
	or() {
		return {
			reduce: (prev, next) => prev || next,
			getInitial: () => false
		};
	},
	and() {
		return {
			reduce: (prev, next) => prev && next,
			getInitial: () => true
		};
	},
	override
};
function override(getInitial) {
	return {
		reduce: (_, item) => item,
		getInitial: () => getInitial?.()
	};
}
var IS_ASYNC_VALIDATION_RESOURCE = Symbol("IS_ASYNC_VALIDATION_RESOURCE");
var MetadataKey = class {
	reducer;
	create;
	brand;
	[IS_ASYNC_VALIDATION_RESOURCE];
	constructor(reducer, create) {
		this.reducer = reducer;
		this.create = create;
	}
};
function createMetadataKey(reducer) {
	return new MetadataKey(reducer ?? MetadataReducer.override());
}
function createManagedMetadataKey(create, reducer) {
	return new MetadataKey(reducer ?? MetadataReducer.override(), create);
}
function createLimitSelectionKey() {
	return createMetadataKey();
}
var REQUIRED = createMetadataKey(MetadataReducer.or());
var MIN = createLimitSelectionKey();
var MIN_DATE = createMetadataKey(MetadataReducer.max());
var MIN_NUMBER = createMetadataKey(MetadataReducer.max());
var MAX = createLimitSelectionKey();
var MAX_DATE = createMetadataKey(MetadataReducer.min());
var MAX_NUMBER = createMetadataKey(MetadataReducer.min());
var MIN_LENGTH = createMetadataKey(MetadataReducer.max());
var MAX_LENGTH = createMetadataKey(MetadataReducer.min());
var PATTERN = createMetadataKey(MetadataReducer.list());
function shallowArrayEquals(a, b) {
	if (a === b) return true;
	if (!a || !b) return false;
	if (a.length !== b.length) return false;
	for (let i = 0; i < a.length; i++) if (!Object.is(a[i], b[i])) return false;
	return true;
}
function calculateValidationSelfStatus(state) {
	if (state.errors().length > 0) return "invalid";
	if (state.pending()) return "unknown";
	return "valid";
}
var FieldValidationState = class {
	node;
	constructor(node) {
		this.node = node;
	}
	rawSyncTreeErrors = computed(() => {
		if (this.shouldSkipValidation()) return [];
		return [...this.node.logicNode.logic.syncTreeErrors.compute(this.node.context), ...this.node.structure.parent?.validationState.rawSyncTreeErrors() ?? []];
	}, {
		...ngDevMode ? { debugName: "rawSyncTreeErrors" } : {},
		equal: shallowArrayEquals
	});
	syncErrors = computed(() => {
		if (this.shouldSkipValidation()) return [];
		return [
			...this.node.logicNode.logic.syncErrors.compute(this.node.context),
			...this.syncTreeErrors(),
			...normalizeErrors$1(this.node.submitState.submissionErrors())
		];
	}, {
		...ngDevMode ? { debugName: "syncErrors" } : {},
		equal: shallowArrayEquals
	});
	syncValid = computed(() => {
		if (this.shouldSkipValidation()) return true;
		return this.node.structure.reduceChildren(this.syncErrors().length === 0, (child, value) => value && child.validationState.syncValid(), shortCircuitFalse);
	}, ...ngDevMode ? [{ debugName: "syncValid" }] : []);
	syncTreeErrors = computed(() => this.rawSyncTreeErrors().filter((err) => err.fieldTree === this.node.fieldTree), {
		...ngDevMode ? { debugName: "syncTreeErrors" } : {},
		equal: shallowArrayEquals
	});
	rawAsyncErrors = computed(() => {
		if (this.shouldSkipValidation()) return [];
		return [...this.node.logicNode.logic.asyncErrors.compute(this.node.context), ...this.node.structure.parent?.validationState.rawAsyncErrors() ?? []];
	}, {
		...ngDevMode ? { debugName: "rawAsyncErrors" } : {},
		equal: shallowArrayEquals
	});
	asyncErrors = computed(() => {
		if (this.shouldSkipValidation()) return [];
		return this.rawAsyncErrors().filter((err) => err === "pending" || err.fieldTree === this.node.fieldTree);
	}, {
		...ngDevMode ? { debugName: "asyncErrors" } : {},
		equal: shallowArrayEquals
	});
	parseErrors = computed(() => this.node.formFieldBindings().flatMap((field) => field.parseErrors()), {
		...ngDevMode ? { debugName: "parseErrors" } : {},
		equal: shallowArrayEquals
	});
	errors = computed(() => [
		...this.parseErrors(),
		...this.syncErrors(),
		...this.asyncErrors().filter((err) => err !== "pending")
	], {
		...ngDevMode ? { debugName: "errors" } : {},
		equal: shallowArrayEquals
	});
	errorSummary = computed(() => {
		const errors = this.node.structure.reduceChildren(this.errors(), (child, result) => [...result, ...child.errorSummary()]);
		untracked(() => errors.sort(compareErrorPosition));
		return errors;
	}, {
		...ngDevMode ? { debugName: "errorSummary" } : {},
		equal: shallowArrayEquals
	});
	pending = computed(() => this.node.structure.reduceChildren(this.asyncErrors().includes("pending"), (child, value) => value || child.validationState.pending()), ...ngDevMode ? [{ debugName: "pending" }] : []);
	status = computed(() => {
		if (this.shouldSkipValidation()) return "valid";
		let ownStatus = calculateValidationSelfStatus(this);
		return this.node.structure.reduceChildren(ownStatus, (child, value) => {
			if (value === "invalid" || child.validationState.status() === "invalid") return "invalid";
			else if (value === "unknown" || child.validationState.status() === "unknown") return "unknown";
			return "valid";
		}, (v) => v === "invalid");
	}, ...ngDevMode ? [{ debugName: "status" }] : []);
	valid = computed(() => this.status() === "valid", ...ngDevMode ? [{ debugName: "valid" }] : []);
	invalid = computed(() => this.status() === "invalid", ...ngDevMode ? [{ debugName: "invalid" }] : []);
	shouldSkipValidation = computed(() => this.node.hidden() || this.node.disabled() || this.node.readonly() || this.node.structure.isOrphaned(), ...ngDevMode ? [{ debugName: "shouldSkipValidation" }] : []);
};
function normalizeErrors$1(error) {
	if (error === void 0) return [];
	if (isArray(error)) return error;
	return [error];
}
function addDefaultField(errors, fieldTree) {
	if (isArray(errors)) for (const error of errors) error.fieldTree ??= fieldTree;
	else if (errors) errors.fieldTree ??= fieldTree;
	return errors;
}
function getFirstBoundElement(error) {
	if (error.formField) return error.formField.element;
	return error.fieldTree().formFieldBindings().reduce((el, binding) => {
		if (!el || !binding.element) return el ?? binding.element;
		return el.compareDocumentPosition(binding.element) & Node.DOCUMENT_POSITION_PRECEDING ? binding.element : el;
	}, void 0);
}
function compareErrorPosition(a, b) {
	const aEl = getFirstBoundElement(a);
	const bEl = getFirstBoundElement(b);
	if (aEl === bEl) return 0;
	if (aEl === void 0 || bEl === void 0) return aEl === void 0 ? 1 : -1;
	return aEl.compareDocumentPosition(bEl) & Node.DOCUMENT_POSITION_PRECEDING ? 1 : -1;
}
var DEBOUNCER = createMetadataKey();
var FieldNodeContext = class {
	node;
	cache = /* @__PURE__ */ new WeakMap();
	constructor(node) {
		this.node = node;
		this.fieldTreeOf = this.fieldTreeOf.bind(this);
		this.stateOf = this.stateOf.bind(this);
	}
	resolve(target) {
		if (!this.cache.has(target)) {
			const resolver = computed(() => {
				const targetPathNode = FieldPathNode.unwrapFieldPath(target);
				let field = this.node;
				let stepsRemaining = getBoundPathDepth();
				while (stepsRemaining > 0 || !field.structure.logic.hasLogic(targetPathNode.root.builder)) {
					stepsRemaining--;
					field = field.structure.parent;
					if (field === void 0) throw new RuntimeError(1900, ngDevMode && "Path is not part of this field tree.");
				}
				for (let key of targetPathNode.keys) {
					field = field.structure.getChild(key);
					if (field === void 0) throw new RuntimeError(1901, ngDevMode && `Cannot resolve path .${targetPathNode.keys.join(".")} relative to field ${["<root>", ...this.node.structure.pathKeys()].join(".")}.`);
				}
				return field.fieldTree;
			}, ...ngDevMode ? [{ debugName: "resolver" }] : []);
			this.cache.set(target, resolver);
		}
		return this.cache.get(target)();
	}
	get fieldTree() {
		return this.node.fieldProxy;
	}
	get state() {
		return this.node;
	}
	get value() {
		return this.node.structure.value;
	}
	get key() {
		return this.node.structure.keyInParent;
	}
	get pathKeys() {
		return this.node.structure.pathKeys;
	}
	index = computed(() => {
		const key = this.key();
		if (!isArray(untracked(this.node.structure.parent.value))) throw new RuntimeError(1906, ngDevMode && "Cannot access index, parent field is not an array.");
		return Number(key);
	}, ...ngDevMode ? [{ debugName: "index" }] : []);
	fieldTreeOf(p) {
		return this.resolve(p);
	}
	stateOf(p) {
		return this.resolve(p)();
	}
	valueOf = (p) => {
		const result = this.resolve(p)().value();
		if (result instanceof AbstractControl) throw new RuntimeError(1907, ngDevMode && `Tried to read an 'AbstractControl' value from a 'form()'. Did you mean to use 'compatForm()' instead?`);
		return result;
	};
};
var FieldMetadataState = class {
	node;
	metadata = /* @__PURE__ */ new Map();
	constructor(node) {
		this.node = node;
	}
	runMetadataCreateLifecycle() {
		if (!this.node.logicNode.logic.hasMetadataKeys()) return;
		const wasInParams = isInParamsFunction();
		if (wasInParams) setInParamsFunction(false);
		try {
			untracked(() => runInInjectionContext(this.node.structure.injector, () => {
				for (const key of this.node.logicNode.logic.getMetadataKeys()) if (key.create) {
					const logic = this.node.logicNode.logic.getMetadata(key);
					const result = key.create(this.node, computed(() => logic.compute(this.node.context)));
					this.metadata.set(key, result);
				}
			}));
		} finally {
			if (wasInParams) setInParamsFunction(true);
		}
	}
	get(key) {
		if (this.has(key)) {
			if (!this.metadata.has(key)) {
				if (key.create) throw new RuntimeError(1912, ngDevMode && "Managed metadata cannot be created lazily");
				const logic = this.node.logicNode.logic.getMetadata(key);
				this.metadata.set(key, computed(() => logic.compute(this.node.context)));
			}
		}
		return this.metadata.get(key);
	}
	has(key) {
		return this.node.logicNode.logic.hasMetadata(key);
	}
};
var FIELD_PROXY_HANDLER = {
	get(getTgt, property, receiver) {
		if (property === FIELD_TREE) return true;
		const tgt = getTgt();
		const child = tgt.structure.getChild(property);
		if (child !== void 0) return child.fieldTree;
		const value = untracked(tgt.value);
		if (isArray(value)) {
			if (property === "length") return tgt.value().length;
			if (property === Symbol.iterator) return () => {
				tgt.value();
				return Array.prototype[Symbol.iterator].apply(tgt.fieldTree);
			};
		}
		if (isObject(value)) {
			if (property === Symbol.iterator) return function* () {
				for (const key in receiver) yield [key, receiver[key]];
			};
		}
	},
	getOwnPropertyDescriptor(getTgt, prop) {
		const value = untracked(getTgt().value);
		const desc = Reflect.getOwnPropertyDescriptor(value, prop);
		if (desc && !desc.configurable) desc.configurable = true;
		return desc;
	},
	ownKeys(getTgt) {
		const value = untracked(getTgt().value);
		return typeof value === "object" && value !== null ? Reflect.ownKeys(value) : [];
	}
};
function deepSignal(source, prop) {
	const read = computed(() => source()[prop()]);
	read[SIGNAL] = source[SIGNAL];
	read.set = (value) => {
		if (Object.is(untracked(read), value)) return;
		source.update((current) => valueForWrite(current, value, prop()));
	};
	read.update = (fn) => {
		read.set(fn(untracked(read)));
	};
	read.asReadonly = () => read;
	return read;
}
function valueForWrite(sourceValue, newPropValue, prop) {
	if (isArray(sourceValue)) {
		const newValue = [...sourceValue];
		newValue[prop] = newPropValue;
		return newValue;
	} else return {
		...sourceValue,
		[prop]: newPropValue
	};
}
var ORPHAN_TOKEN = Symbol(typeof ngDevMode !== "undefined" && ngDevMode ? "ORPHAN_TOKEN" : "");
var FALSE_SIGNAL = computed(() => false, ...ngDevMode ? [{ debugName: "FALSE_SIGNAL" }] : []);
var FieldNodeStructure = class {
	logic;
	node;
	createChildNode;
	identitySymbol = Symbol();
	_injector = void 0;
	_anyChildHasLogic;
	get injector() {
		this._injector ??= Injector.create({
			providers: [],
			parent: this.fieldManager.injector
		});
		return this._injector;
	}
	constructor(logic, node, createChildNode) {
		this.logic = logic;
		this.node = node;
		this.createChildNode = createChildNode;
	}
	children() {
		this.ensureChildrenMap();
		const map = this.childrenMap();
		if (map === void 0) return [];
		return Array.from(map.byPropertyKey.values()).map((child) => untracked(child.reader));
	}
	materializedChildren() {
		const map = this.childrenMap();
		if (map === void 0) return [];
		return Array.from(map.byPropertyKey.values()).map((child) => child.node);
	}
	_areChildrenMaterialized() {
		return untracked(this.childrenMap) !== void 0;
	}
	ensureChildrenMap() {
		if (this._areChildrenMaterialized()) return;
		untracked(() => {
			this.childrenMap.update((current) => this.computeChildrenMap(this.value(), current, true));
		});
	}
	getChild(key) {
		this.ensureChildrenMap();
		const strKey = key.toString();
		let reader = untracked(this.childrenMap)?.byPropertyKey.get(strKey)?.reader;
		if (!reader) reader = this.createReader(strKey);
		return reader();
	}
	reduceChildren(initialValue, fn, shortCircuit) {
		const map = this.childrenMap();
		if (!map) return initialValue;
		let value = initialValue;
		for (const child of map.byPropertyKey.values()) {
			if (shortCircuit?.(value)) break;
			value = fn(untracked(child.reader), value);
		}
		return value;
	}
	destroy() {
		this.injector.destroy();
	}
	createKeyOrOrphanSignals(kind, identityInParent, initialKeyInParent) {
		if (kind === "root") return {
			keyInParent: ROOT_KEY_IN_PARENT,
			isOrphaned: FALSE_SIGNAL
		};
		const parent = this.parent;
		let lastKnownKey = initialKeyInParent;
		const keyOrOrphan = computed(() => {
			if (parent.structure.isOrphaned()) return ORPHAN_TOKEN;
			const map = parent.structure.childrenMap();
			if (!map) return ORPHAN_TOKEN;
			const lastKnownChild = map.byPropertyKey.get(lastKnownKey);
			if (lastKnownChild && lastKnownChild.node === this.node) return lastKnownKey;
			if (identityInParent === void 0) return ORPHAN_TOKEN;
			else {
				for (const [key, child] of map.byPropertyKey) if (child.node === this.node) return lastKnownKey = key;
				return ORPHAN_TOKEN;
			}
		}, ...ngDevMode ? [{ debugName: "keyOrOrphan" }] : []);
		const isOrphaned = computed(() => keyOrOrphan() === ORPHAN_TOKEN, ...ngDevMode ? [{ debugName: "isOrphaned" }] : []);
		return {
			keyInParent: computed(() => {
				const key = keyOrOrphan();
				if (key === ORPHAN_TOKEN) if (identityInParent === void 0) throw new RuntimeError(-1902, ngDevMode && `Orphan field, looking for property '${initialKeyInParent}' of ${getDebugName(parent)}`);
				else throw new RuntimeError(1904, ngDevMode && `Orphan field, can't find element in array ${getDebugName(parent)}`);
				return key;
			}, ...ngDevMode ? [{ debugName: "keyInParent" }] : []),
			isOrphaned
		};
	}
	createChildrenMap() {
		return linkedSignal({
			source: this.value,
			computation: (value, previous) => this.computeChildrenMap(value, previous?.value, false)
		});
	}
	computeChildrenMap(value, prevData, forceMaterialize) {
		if (!isObject(value)) return;
		if (!forceMaterialize && prevData === void 0) {
			if (!(this._anyChildHasLogic ??= this.logic.anyChildHasLogic())) return;
		}
		prevData ??= { byPropertyKey: /* @__PURE__ */ new Map() };
		let materializedChildren;
		const parentIsArray = isArray(value);
		if (prevData !== void 0) if (parentIsArray) materializedChildren = maybeRemoveStaleArrayFields(prevData, value, this.identitySymbol);
		else materializedChildren = maybeRemoveStaleObjectFields(prevData, value);
		for (const key of Object.keys(value)) {
			let trackingKey = void 0;
			const childValue = value[key];
			if (childValue === void 0) {
				if (prevData.byPropertyKey.has(key)) {
					materializedChildren ??= { ...prevData };
					materializedChildren.byPropertyKey.delete(key);
				}
				continue;
			}
			if (parentIsArray && isObject(childValue) && !isArray(childValue)) trackingKey = childValue[this.identitySymbol] ??= Symbol(ngDevMode ? `id:${globalId++}` : "");
			let childNode;
			if (trackingKey) {
				if (!prevData.byTrackingKey?.has(trackingKey)) {
					materializedChildren ??= { ...prevData };
					materializedChildren.byTrackingKey ??= /* @__PURE__ */ new Map();
					materializedChildren.byTrackingKey.set(trackingKey, this.createChildNode(key, trackingKey, parentIsArray));
				}
				childNode = (materializedChildren ?? prevData).byTrackingKey.get(trackingKey);
			}
			const child = prevData.byPropertyKey.get(key);
			if (child === void 0) {
				materializedChildren ??= { ...prevData };
				materializedChildren.byPropertyKey.set(key, {
					reader: this.createReader(key),
					node: childNode ?? this.createChildNode(key, trackingKey, parentIsArray)
				});
			} else if (childNode && childNode !== child.node) {
				materializedChildren ??= { ...prevData };
				child.node = childNode;
			}
		}
		return materializedChildren ?? prevData;
	}
	createReader(key) {
		return computed(() => this.childrenMap()?.byPropertyKey.get(key)?.node);
	}
};
var RootFieldNodeStructure = class extends FieldNodeStructure {
	fieldManager;
	value;
	get parent() {}
	get root() {
		return this.node;
	}
	get pathKeys() {
		return ROOT_PATH_KEYS;
	}
	get keyInParent() {
		return ROOT_KEY_IN_PARENT;
	}
	isOrphaned = FALSE_SIGNAL;
	childrenMap;
	constructor(node, logic, fieldManager, value, createChildNode) {
		super(logic, node, createChildNode);
		this.fieldManager = fieldManager;
		this.value = value;
		this.childrenMap = this.createChildrenMap();
	}
};
var ChildFieldNodeStructure = class extends FieldNodeStructure {
	logic;
	parent;
	root;
	pathKeys;
	keyInParent;
	value;
	childrenMap;
	isOrphaned;
	get fieldManager() {
		return this.root.structure.fieldManager;
	}
	constructor(node, logic, parent, identityInParent, initialKeyInParent, createChildNode) {
		super(logic, node, createChildNode);
		this.logic = logic;
		this.parent = parent;
		this.root = this.parent.structure.root;
		const signals = this.createKeyOrOrphanSignals("child", identityInParent, initialKeyInParent);
		this.isOrphaned = signals.isOrphaned;
		this.keyInParent = signals.keyInParent;
		this.pathKeys = computed(() => [...parent.structure.pathKeys(), this.keyInParent()], ...ngDevMode ? [{ debugName: "pathKeys" }] : []);
		this.value = deepSignal(this.parent.structure.value, this.keyInParent);
		this.childrenMap = this.createChildrenMap();
		this.fieldManager.structures.add(this);
	}
};
var globalId = 0;
var ROOT_PATH_KEYS = computed(() => [], ...ngDevMode ? [{ debugName: "ROOT_PATH_KEYS" }] : []);
var ROOT_KEY_IN_PARENT = computed(() => {
	throw new RuntimeError(1905, ngDevMode && "The top-level field in the form has no parent.");
}, ...ngDevMode ? [{ debugName: "ROOT_KEY_IN_PARENT" }] : []);
function getDebugName(node) {
	return `<root>.${node.structure.pathKeys().join(".")}`;
}
function maybeRemoveStaleArrayFields(prevData, value, identitySymbol) {
	let data;
	const oldKeys = new Set(prevData.byPropertyKey.keys());
	const oldTracking = prevData.byTrackingKey && new Set(prevData.byTrackingKey.keys());
	for (let i = 0; i < value.length; i++) {
		const childValue = value[i];
		oldKeys.delete(i.toString());
		if (oldTracking && isObject(childValue) && Object.hasOwn(childValue, identitySymbol)) oldTracking.delete(childValue[identitySymbol]);
	}
	if (oldKeys.size > 0) {
		data ??= { ...prevData };
		for (const key of oldKeys) data.byPropertyKey.delete(key);
	}
	if (oldTracking && oldTracking.size > 0) {
		data ??= { ...prevData };
		for (const id of oldTracking) data.byTrackingKey.delete(id);
	}
	return data;
}
function maybeRemoveStaleObjectFields(prevData, value) {
	let data;
	for (const key of prevData.byPropertyKey.keys()) if (!Object.hasOwn(value, key)) {
		data ??= { ...prevData };
		data.byPropertyKey.delete(key);
	}
	return data;
}
var FieldSubmitState = class {
	node;
	selfSubmitting = signal(false, ...ngDevMode ? [{ debugName: "selfSubmitting" }] : []);
	submissionErrors;
	constructor(node) {
		this.node = node;
		this.submissionErrors = linkedSignal({
			...ngDevMode ? { debugName: "submissionErrors" } : {},
			source: this.node.structure.value,
			computation: () => []
		});
	}
	submitting = computed(() => {
		return this.selfSubmitting() || (this.node.structure.parent?.submitting() ?? false);
	}, ...ngDevMode ? [{ debugName: "submitting" }] : []);
};
var FieldNode = class {
	structure;
	validationState;
	metadataState;
	nodeState;
	submitState;
	fieldAdapter;
	controlValue;
	_context = void 0;
	get context() {
		return this._context ??= new FieldNodeContext(this);
	}
	fieldProxy = new Proxy(() => this, FIELD_PROXY_HANDLER);
	pathNode;
	constructor(options) {
		this.pathNode = options.pathNode;
		this.fieldAdapter = options.fieldAdapter;
		this.structure = this.fieldAdapter.createStructure(this, options);
		this.validationState = this.fieldAdapter.createValidationState(this, options);
		this.nodeState = this.fieldAdapter.createNodeState(this, options);
		this.metadataState = new FieldMetadataState(this);
		this.submitState = new FieldSubmitState(this);
		this.controlValue = this.controlValueSignal();
		this.metadataState.runMetadataCreateLifecycle();
	}
	focusBoundControl(options) {
		this.getBindingForFocus()?.focus(options);
	}
	getBindingForFocus() {
		const own = this.formFieldBindings().filter((b) => b.focus !== void 0).reduce(firstInDom, void 0);
		if (own) return own;
		return this.structure.children().map((child) => child.getBindingForFocus()).reduce(firstInDom, void 0);
	}
	pendingSync = linkedSignal({
		...ngDevMode ? { debugName: "pendingSync" } : {},
		source: () => this.value(),
		computation: (_source, previous) => {
			previous?.value?.abort();
		}
	});
	get fieldTree() {
		return this.fieldProxy;
	}
	get logicNode() {
		return this.structure.logic;
	}
	get value() {
		return this.structure.value;
	}
	get keyInParent() {
		return this.structure.keyInParent;
	}
	get errors() {
		return this.validationState.errors;
	}
	get parseErrors() {
		return this.validationState.parseErrors;
	}
	get errorSummary() {
		return this.validationState.errorSummary;
	}
	get pending() {
		return this.validationState.pending;
	}
	get valid() {
		return this.validationState.valid;
	}
	get invalid() {
		return this.validationState.invalid;
	}
	get dirty() {
		return this.nodeState.dirty;
	}
	get touched() {
		return this.nodeState.touched;
	}
	get disabled() {
		return this.nodeState.disabled;
	}
	get disabledReasons() {
		return this.nodeState.disabledReasons;
	}
	get hidden() {
		return this.nodeState.hidden;
	}
	get readonly() {
		return this.nodeState.readonly;
	}
	get formFieldBindings() {
		return this.nodeState.formFieldBindings;
	}
	get submitting() {
		return this.submitState.submitting;
	}
	get name() {
		return this.nodeState.name;
	}
	get max() {
		const maxKey = this.metadata(MAX)?.();
		return maxKey ? this.metadata(maxKey) : void 0;
	}
	get maxLength() {
		return this.metadata(MAX_LENGTH);
	}
	get min() {
		const minKey = this.metadata(MIN)?.();
		return minKey ? this.metadata(minKey) : void 0;
	}
	get minLength() {
		return this.metadata(MIN_LENGTH);
	}
	get pattern() {
		return this.metadata(PATTERN) ?? EMPTY;
	}
	get required() {
		return this.metadata(REQUIRED) ?? FALSE;
	}
	metadata(key) {
		return this.metadataState.get(key);
	}
	getError(kind) {
		return this.errors().find((e) => e.kind === kind);
	}
	hasMetadata(key) {
		return this.metadataState.has(key);
	}
	markAsTouched(options) {
		if (this.structure.isOrphaned()) return;
		untracked(() => {
			this.markAsTouchedInternal(options);
			this.flushSync();
		});
	}
	markAsTouchedInternal(options) {
		if (this.structure.isOrphaned()) return;
		if (this.validationState.shouldSkipValidation()) return;
		this.nodeState.markAsTouched();
		if (options?.skipDescendants) return;
		for (const child of this.structure.children()) child.markAsTouchedInternal();
	}
	markAsDirty() {
		this.nodeState.markAsDirty();
	}
	markAsPristine() {
		this.nodeState.markAsPristine();
	}
	markAsUntouched() {
		this.nodeState.markAsUntouched();
	}
	reset(value) {
		untracked(() => this._reset(value));
	}
	_reset(value) {
		this.pendingSync()?.abort();
		if (value !== void 0) this.value.set(value);
		this.controlValue.rawSet(this.value());
		this.nodeState.markAsUntouched();
		this.nodeState.markAsPristine();
		for (const binding of this.formFieldBindings()) binding.reset();
		for (const child of this.structure.materializedChildren()) child._reset();
	}
	reloadValidation() {
		untracked(() => this._reloadValidation());
	}
	_reloadValidation() {
		const keys = this.logicNode.logic.getMetadataKeys();
		for (const key of keys) if (key[IS_ASYNC_VALIDATION_RESOURCE]) this.metadata(key).reload?.();
		for (const child of this.structure.children()) child._reloadValidation();
	}
	controlValueSignal() {
		const controlValue = linkedSignal(this.value);
		controlValue.rawSet = controlValue.set;
		controlValue.set = (newValue) => {
			controlValue.rawSet(newValue);
			this.markAsDirty();
			this.debounceSync();
		};
		const rawUpdate = controlValue.update;
		controlValue.update = (updateFn) => {
			rawUpdate(updateFn);
			this.markAsDirty();
			this.debounceSync();
		};
		return controlValue;
	}
	sync() {
		this.value.set(this.controlValue());
	}
	flushSync() {
		const pending = this.pendingSync();
		if (pending && !pending.signal.aborted) {
			pending.abort();
			this.sync();
		}
	}
	async debounceSync() {
		const debouncer = untracked(() => {
			this.pendingSync()?.abort();
			return this.nodeState.debouncer();
		});
		if (debouncer) {
			const controller = new AbortController();
			const promise = debouncer(controller.signal);
			if (promise) {
				this.pendingSync.set(controller);
				await promise;
				if (controller.signal.aborted) return;
			}
		}
		if (this.structure.isOrphaned()) return;
		this.sync();
	}
	static newRoot(fieldManager, value, pathNode, adapter) {
		return adapter.newRoot(fieldManager, value, pathNode, adapter);
	}
	createStructure(options) {
		return options.kind === "root" ? new RootFieldNodeStructure(this, options.logic, options.fieldManager, options.value, this.newChild.bind(this)) : new ChildFieldNodeStructure(this, options.logic, options.parent, options.identityInParent, options.initialKeyInParent, this.newChild.bind(this));
	}
	newChild(key, trackingId, isArray) {
		let childPath;
		let childLogic;
		if (isArray) {
			childPath = this.pathNode.getChild(DYNAMIC);
			childLogic = this.structure.logic.getChild(DYNAMIC);
		} else {
			childPath = this.pathNode.getChild(key);
			childLogic = this.structure.logic.getChild(key);
		}
		return this.fieldAdapter.newChild({
			kind: "child",
			parent: this,
			pathNode: childPath,
			logic: childLogic,
			initialKeyInParent: key,
			identityInParent: trackingId,
			fieldAdapter: this.fieldAdapter
		});
	}
};
var EMPTY = computed(() => [], ...ngDevMode ? [{ debugName: "EMPTY" }] : []);
var FALSE = computed(() => false, ...ngDevMode ? [{ debugName: "FALSE" }] : []);
function firstInDom(a, b) {
	if (!a) return b;
	if (!b) return a;
	return a.element.compareDocumentPosition(b.element) & Node.DOCUMENT_POSITION_PRECEDING ? b : a;
}
var FieldNodeState = class {
	node;
	selfTouched = signal(false, ...ngDevMode ? [{ debugName: "selfTouched" }] : []);
	selfDirty = signal(false, ...ngDevMode ? [{ debugName: "selfDirty" }] : []);
	markAsTouched() {
		this.selfTouched.set(true);
	}
	markAsDirty() {
		this.selfDirty.set(true);
	}
	markAsPristine() {
		this.selfDirty.set(false);
	}
	markAsUntouched() {
		this.selfTouched.set(false);
	}
	formFieldBindings = signal([], ...ngDevMode ? [{ debugName: "formFieldBindings" }] : []);
	constructor(node) {
		this.node = node;
	}
	dirty = computed(() => {
		const selfDirtyValue = this.selfDirty() && !this.isNonInteractive();
		return this.node.structure.reduceChildren(selfDirtyValue, (child, value) => value || child.nodeState.dirty(), shortCircuitTrue);
	}, ...ngDevMode ? [{ debugName: "dirty" }] : []);
	touched = computed(() => {
		const selfTouchedValue = this.selfTouched() && !this.isNonInteractive();
		return this.node.structure.reduceChildren(selfTouchedValue, (child, value) => value || child.nodeState.touched(), shortCircuitTrue);
	}, ...ngDevMode ? [{ debugName: "touched" }] : []);
	disabledReasons = computed(() => [...this.node.structure.parent?.nodeState.disabledReasons() ?? [], ...this.node.logicNode.logic.disabledReasons.compute(this.node.context)], {
		...ngDevMode ? { debugName: "disabledReasons" } : {},
		equal: shallowArrayEquals
	});
	disabled = computed(() => !!this.disabledReasons().length, ...ngDevMode ? [{ debugName: "disabled" }] : []);
	readonly = computed(() => (this.node.structure.parent?.nodeState.readonly() || this.node.logicNode.logic.readonly.compute(this.node.context)) ?? false, ...ngDevMode ? [{ debugName: "readonly" }] : []);
	hidden = computed(() => (this.node.structure.parent?.nodeState.hidden() || this.node.logicNode.logic.hidden.compute(this.node.context)) ?? false, ...ngDevMode ? [{ debugName: "hidden" }] : []);
	name = computed(() => {
		const parent = this.node.structure.parent;
		if (!parent) return this.node.structure.fieldManager.rootName;
		return `${parent.name()}.${this.node.structure.keyInParent()}`;
	}, ...ngDevMode ? [{ debugName: "name" }] : []);
	debouncer = computed(() => {
		if (this.node.logicNode.logic.hasMetadata(DEBOUNCER)) {
			const debouncer = this.node.logicNode.logic.getMetadata(DEBOUNCER).compute(this.node.context);
			if (debouncer) return (signal) => debouncer(this.node.context, signal);
		}
		return this.node.structure.parent?.nodeState.debouncer?.();
	}, ...ngDevMode ? [{ debugName: "debouncer" }] : []);
	isNonInteractive = computed(() => this.hidden() || this.disabled() || this.readonly(), ...ngDevMode ? [{ debugName: "isNonInteractive" }] : []);
};
var BasicFieldAdapter = class {
	newRoot(fieldManager, value, pathNode, adapter) {
		return new FieldNode({
			kind: "root",
			fieldManager,
			value,
			pathNode,
			logic: pathNode.builder.build(),
			fieldAdapter: adapter
		});
	}
	newChild(options) {
		return new FieldNode(options);
	}
	createNodeState(node) {
		return new FieldNodeState(node);
	}
	createValidationState(node) {
		return new FieldValidationState(node);
	}
	createStructure(node, options) {
		return node.createStructure(options);
	}
};
var FormFieldManager = class {
	injector;
	rootName;
	submitOptions;
	constructor(injector, rootName, submitOptions) {
		this.injector = injector;
		this.rootName = rootName ?? `${this.injector.get(APP_ID)}.form${nextFormId++}`;
		this.submitOptions = submitOptions;
	}
	structures = /* @__PURE__ */ new Set();
	createFieldManagementEffect(root) {
		effect(() => {
			const liveStructures = /* @__PURE__ */ new Set();
			this.markStructuresLive(root, liveStructures);
			for (const structure of this.structures) if (!liveStructures.has(structure)) {
				this.structures.delete(structure);
				untracked(() => structure.destroy());
			}
		}, { injector: this.injector });
	}
	markStructuresLive(structure, liveStructures) {
		liveStructures.add(structure);
		for (const child of structure.children()) this.markStructuresLive(child.structure, liveStructures);
	}
};
var nextFormId = 0;
var REGISTER_WEBMCP_FORM = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "REGISTER_WEBMCP_FORM" : "");
function normalizeFormArgs(args) {
	let model;
	let schema;
	let options;
	if (args.length === 3) [model, schema, options] = args;
	else if (args.length === 2) if (isSchemaOrSchemaFn(args[1])) [model, schema] = args;
	else [model, options] = args;
	else [model] = args;
	return [
		model,
		schema,
		options
	];
}
function form(...args) {
	const [model, schema, options] = normalizeFormArgs(args);
	const injector = options?.injector ?? inject(Injector);
	const pathNode = runInInjectionContext(injector, () => SchemaImpl.rootCompile(schema));
	const fieldManager = new FormFieldManager(injector, options?.name, options?.submission);
	const adapter = options?.adapter ?? new BasicFieldAdapter();
	const fieldRoot = FieldNode.newRoot(fieldManager, model, pathNode, adapter);
	fieldManager.createFieldManagementEffect(fieldRoot.structure);
	const { experimentalWebMcpTool } = options ?? {};
	if (experimentalWebMcpTool) {
		const registerWebMcpForm = runInInjectionContext(injector, () => inject(REGISTER_WEBMCP_FORM, { optional: true }));
		if (registerWebMcpForm) runInInjectionContext(injector, () => registerWebMcpForm(fieldRoot.fieldTree, {
			name: experimentalWebMcpTool.name,
			description: experimentalWebMcpTool.description
		}));
		else if (typeof ngDevMode !== "undefined" && ngDevMode) throw new Error(`Cannot register form "${experimentalWebMcpTool.name}" as a WebMCP tool. Make sure to use \`provideExperimentalWebMcpForms()\` in your application bootstrap configuration.`);
	}
	return fieldRoot.fieldTree;
}
function applyEach(path, schema) {
	assertPathIsCurrent(path);
	const elementPath = FieldPathNode.unwrapFieldPath(path).getChild(DYNAMIC).fieldPathProxy;
	apply(elementPath, schema);
}
function apply(path, schema) {
	assertPathIsCurrent(path);
	FieldPathNode.unwrapFieldPath(path).mergeIn(SchemaImpl.create(schema));
}
function applyWhen(path, logic, schema) {
	assertPathIsCurrent(path);
	FieldPathNode.unwrapFieldPath(path).mergeIn(SchemaImpl.create(schema), {
		fn: logic,
		path
	});
}
function applyWhenValue(path, predicate, schema) {
	applyWhen(path, ({ value }) => predicate(value()), schema);
}
async function submit(form, options) {
	const node = untracked(form);
	if (untracked(node.submitState.submitting)) return false;
	const field = options === void 0 ? node.structure.root.fieldProxy : form;
	const detail = {
		root: node.structure.root.fieldProxy,
		submitted: form
	};
	options = typeof options === "function" ? { action: options } : options ?? node.structure.fieldManager.submitOptions;
	const action = options?.action;
	if (!action) throw new RuntimeError(1915, (typeof ngDevMode === "undefined" || ngDevMode) && "Cannot submit form with no submit action. Specify the action when creating the form, or as an additional argument to `submit()`.");
	node.markAsTouched();
	const onInvalid = options?.onInvalid;
	const shouldRun = shouldRunAction(node, options?.ignoreValidators);
	try {
		if (shouldRun) {
			node.submitState.selfSubmitting.set(true);
			const errors = await untracked(() => action?.(field, detail));
			errors && setSubmissionErrors(node, errors);
			return !errors || isArray(errors) && errors.length === 0;
		} else untracked(() => onInvalid?.(field, detail));
		return false;
	} finally {
		node.submitState.selfSubmitting.set(false);
	}
}
function schema(fn) {
	return SchemaImpl.create(fn);
}
function shouldRunAction(node, ignoreValidators) {
	switch (ignoreValidators) {
		case "all": return true;
		case "none": return untracked(node.valid);
		default: return !untracked(node.invalid);
	}
}
function setSubmissionErrors(submittedField, errors) {
	if (!isArray(errors)) errors = [errors];
	const errorsByField = /* @__PURE__ */ new Map();
	for (const error of errors) {
		const errorWithField = addDefaultField(error, submittedField.fieldTree);
		const field = errorWithField.fieldTree();
		let fieldErrors = errorsByField.get(field);
		if (!fieldErrors) {
			fieldErrors = [];
			errorsByField.set(field, fieldErrors);
		}
		fieldErrors.push(errorWithField);
	}
	for (const [field, fieldErrors] of errorsByField) field.submitState.submissionErrors.set(fieldErrors);
}
var CompatValidationError = class {
	kind = "compat";
	control;
	fieldTree;
	context;
	message;
	constructor({ context, kind, control }) {
		this.context = context;
		this.kind = kind;
		this.control = control;
	}
};
function signalErrorsToValidationErrors(errors) {
	if (errors.length === 0) return null;
	const errObj = {};
	for (const error of errors) errObj[error.kind] = error instanceof CompatValidationError ? error.context : error;
	return errObj;
}
function reactiveErrorsToSignalErrors(errors, control) {
	if (errors === null) return [];
	return Object.entries(errors).map(([kind, context]) => {
		return new CompatValidationError({
			context,
			kind,
			control
		});
	});
}
//#endregion
//#region node_modules/@angular/forms/fesm2022/signals.mjs
/**
* @license Angular v22.1.7
* (c) 2010-2026 Google LLC. https://angular.dev/
* License: MIT
*/
function isFieldTree(value) {
	return typeof value === "function" && value[FIELD_TREE] === true;
}
var SIGNAL_FORMS_CONFIG = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "SIGNAL_FORMS_CONFIG" : "");
function provideSignalFormsConfig(config) {
	return [{
		provide: SIGNAL_FORMS_CONFIG,
		useValue: config
	}];
}
function disabled(path, configOrLogic) {
	assertPathIsCurrent(path);
	const pathNode = FieldPathNode.unwrapFieldPath(path);
	let logic;
	if (typeof configOrLogic === "function" || typeof configOrLogic === "string") logic = configOrLogic;
	else logic = configOrLogic?.when;
	pathNode.builder.addDisabledReasonRule((ctx) => {
		let result = true;
		if (typeof logic === "string") result = logic;
		else if (logic) result = logic(ctx);
		if (typeof result === "string") return {
			fieldTree: ctx.fieldTree,
			message: result
		};
		return result ? { fieldTree: ctx.fieldTree } : void 0;
	});
}
function hidden(path, configOrLogic) {
	assertPathIsCurrent(path);
	const pathNode = FieldPathNode.unwrapFieldPath(path);
	const logic = typeof configOrLogic === "function" ? configOrLogic : configOrLogic.when;
	pathNode.builder.addHiddenRule(logic);
}
function readonly(path, configOrLogic) {
	assertPathIsCurrent(path);
	const pathNode = FieldPathNode.unwrapFieldPath(path);
	const logic = typeof configOrLogic === "function" ? configOrLogic : configOrLogic?.when ?? (() => true);
	pathNode.builder.addReadonlyRule(logic);
}
function getLengthOrSize(value) {
	const v = value;
	return typeof v.length === "number" ? v.length : v.size;
}
function getOption(opt, ctx) {
	return opt instanceof Function ? opt(ctx) : opt;
}
function isEmpty(value) {
	if (typeof value === "number") return isNaN(value);
	return value === "" || value === false || value == null;
}
function normalizeErrors(error) {
	if (error === void 0) return [];
	if (Array.isArray(error)) return error;
	return [error];
}
function validate(path, logic) {
	assertPathIsCurrent(path);
	FieldPathNode.unwrapFieldPath(path).builder.addSyncErrorRule((ctx) => {
		return addDefaultField(logic(ctx), ctx.fieldTree);
	});
}
function requiredError(options) {
	return new RequiredValidationError(options);
}
function minError(min, options) {
	return new MinValidationError(min, options);
}
function minDateError(minDate, options) {
	return new MinDateValidationError(minDate, options);
}
function maxError(max, options) {
	return new MaxValidationError(max, options);
}
function maxDateError(maxDate, options) {
	return new MaxDateValidationError(maxDate, options);
}
function minLengthError(minLength, options) {
	return new MinLengthValidationError(minLength, options);
}
function maxLengthError(maxLength, options) {
	return new MaxLengthValidationError(maxLength, options);
}
function patternError(pattern, options) {
	return new PatternValidationError(pattern, options);
}
function emailError(options) {
	return new EmailValidationError(options);
}
var BaseNgValidationError = class {
	__brand = void 0;
	kind = "";
	fieldTree;
	message;
	constructor(options) {
		if (options) Object.assign(this, options);
	}
};
var RequiredValidationError = class extends BaseNgValidationError {
	kind = "required";
};
var MinValidationError = class extends BaseNgValidationError {
	min;
	kind = "min";
	constructor(min, options) {
		super(options);
		this.min = min;
	}
};
var MinDateValidationError = class extends BaseNgValidationError {
	minDate;
	kind = "minDate";
	constructor(minDate, options) {
		super(options);
		this.minDate = minDate;
	}
};
var MaxValidationError = class extends BaseNgValidationError {
	max;
	kind = "max";
	constructor(max, options) {
		super(options);
		this.max = max;
	}
};
var MaxDateValidationError = class extends BaseNgValidationError {
	maxDate;
	kind = "maxDate";
	constructor(maxDate, options) {
		super(options);
		this.maxDate = maxDate;
	}
};
var MinLengthValidationError = class extends BaseNgValidationError {
	minLength;
	kind = "minLength";
	constructor(minLength, options) {
		super(options);
		this.minLength = minLength;
	}
};
var MaxLengthValidationError = class extends BaseNgValidationError {
	maxLength;
	kind = "maxLength";
	constructor(maxLength, options) {
		super(options);
		this.maxLength = maxLength;
	}
};
var PatternValidationError = class extends BaseNgValidationError {
	pattern;
	kind = "pattern";
	constructor(pattern, options) {
		super(options);
		this.pattern = pattern;
	}
};
var EmailValidationError = class extends BaseNgValidationError {
	kind = "email";
};
var NativeInputParseError = class extends BaseNgValidationError {
	kind = "parse";
};
var NgValidationError = BaseNgValidationError;
var EMAIL_REGEXP = /^(?=.{1,254}$)(?=.{1,64}@)[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
function email(path, config) {
	validate(path, (ctx) => {
		if (config?.when && !config.when(ctx)) return;
		if (isEmpty(ctx.value())) return;
		if (!EMAIL_REGEXP.test(ctx.value())) if (config?.error) return getOption(config.error, ctx);
		else return emailError({ message: getOption(config?.message, ctx) });
	});
}
function max(path, maxValue, config) {
	const MAX_MEMO = createMetadataKey();
	metadata(path, MAX_MEMO, (ctx) => {
		if (config?.when && !config.when(ctx)) return;
		return typeof maxValue === "function" ? maxValue(ctx) : maxValue;
	});
	metadata(path, MAX_NUMBER, ({ state }) => state.metadata(MAX_MEMO)());
	metadata(path, MAX, () => MAX_NUMBER);
	validate(path, (ctx) => {
		const value = ctx.value();
		if (value === null || Number.isNaN(value)) return;
		const max = ctx.state.metadata(MAX_MEMO)();
		if (max === void 0 || Number.isNaN(max)) return;
		if (value > max) if (config?.error) return getOption(config.error, ctx);
		else return maxError(max, { message: getOption(config?.message, ctx) });
	});
}
function maxDate(path, maxDateValue, config) {
	const MAX_MEMO = createMetadataKey();
	metadata(path, MAX_MEMO, (ctx) => {
		if (config?.when && !config.when(ctx)) return;
		return typeof maxDateValue === "function" ? maxDateValue(ctx) : maxDateValue;
	});
	metadata(path, MAX_DATE, ({ state }) => state.metadata(MAX_MEMO)());
	metadata(path, MAX, () => MAX_DATE);
	validate(path, (ctx) => {
		const value = ctx.value();
		if (value === null || Number.isNaN(value.getTime())) return;
		const max = ctx.state.metadata(MAX_MEMO)();
		if (max === void 0 || Number.isNaN(max.getTime())) return;
		if (value > max) if (config?.error) return getOption(config.error, ctx);
		else return maxDateError(max, { message: getOption(config?.message, ctx) });
	});
}
function maxLength(path, maxLength, config) {
	const MAX_LENGTH_MEMO = metadata(path, createMetadataKey(), (ctx) => {
		if (config?.when && !config.when(ctx)) return;
		return typeof maxLength === "number" ? maxLength : maxLength(ctx);
	});
	metadata(path, MAX_LENGTH, ({ state }) => state.metadata(MAX_LENGTH_MEMO)());
	validate(path, (ctx) => {
		if (isEmpty(ctx.value())) return;
		const maxLength = ctx.state.metadata(MAX_LENGTH_MEMO)();
		if (maxLength === void 0) return;
		if (getLengthOrSize(ctx.value()) > maxLength) if (config?.error) return getOption(config.error, ctx);
		else return maxLengthError(maxLength, { message: getOption(config?.message, ctx) });
	});
}
function min(path, minValue, config) {
	const MIN_MEMO = createMetadataKey();
	metadata(path, MIN_MEMO, (ctx) => {
		if (config?.when && !config.when(ctx)) return;
		return typeof minValue === "function" ? minValue(ctx) : minValue;
	});
	metadata(path, MIN_NUMBER, ({ state }) => state.metadata(MIN_MEMO)());
	metadata(path, MIN, () => MIN_NUMBER);
	validate(path, (ctx) => {
		const value = ctx.value();
		if (value === null || Number.isNaN(value)) return;
		const min = ctx.state.metadata(MIN_MEMO)();
		if (min === void 0 || Number.isNaN(min)) return;
		if (value < min) if (config?.error) return getOption(config.error, ctx);
		else return minError(min, { message: getOption(config?.message, ctx) });
	});
}
function minDate(path, minDateValue, config) {
	const MIN_MEMO = createMetadataKey();
	metadata(path, MIN_MEMO, (ctx) => {
		if (config?.when && !config.when(ctx)) return;
		return typeof minDateValue === "function" ? minDateValue(ctx) : minDateValue;
	});
	metadata(path, MIN_DATE, ({ state }) => state.metadata(MIN_MEMO)());
	metadata(path, MIN, () => MIN_DATE);
	validate(path, (ctx) => {
		const value = ctx.value();
		if (value === null || Number.isNaN(value.getTime())) return;
		const min = ctx.state.metadata(MIN_MEMO)();
		if (min === void 0 || Number.isNaN(min.getTime())) return;
		if (value < min) if (config?.error) return getOption(config.error, ctx);
		else return minDateError(min, { message: getOption(config?.message, ctx) });
	});
}
function minLength(path, minLength, config) {
	const MIN_LENGTH_MEMO = metadata(path, createMetadataKey(), (ctx) => {
		if (config?.when && !config.when(ctx)) return;
		return typeof minLength === "number" ? minLength : minLength(ctx);
	});
	metadata(path, MIN_LENGTH, ({ state }) => state.metadata(MIN_LENGTH_MEMO)());
	validate(path, (ctx) => {
		if (isEmpty(ctx.value())) return;
		const minLength = ctx.state.metadata(MIN_LENGTH_MEMO)();
		if (minLength === void 0) return;
		if (getLengthOrSize(ctx.value()) < minLength) if (config?.error) return getOption(config.error, ctx);
		else return minLengthError(minLength, { message: getOption(config?.message, ctx) });
	});
}
function pattern(path, pattern, config) {
	const PATTERN_MEMO = metadata(path, createMetadataKey(), (ctx) => {
		if (config?.when && !config.when(ctx)) return;
		return pattern instanceof RegExp ? pattern : pattern(ctx);
	});
	metadata(path, PATTERN, ({ state }) => state.metadata(PATTERN_MEMO)());
	validate(path, (ctx) => {
		if (isEmpty(ctx.value())) return;
		const pattern = ctx.state.metadata(PATTERN_MEMO)();
		if (pattern === void 0) return;
		if (!pattern.test(ctx.value())) if (config?.error) return getOption(config.error, ctx);
		else return patternError(pattern, { message: getOption(config?.message, ctx) });
	});
}
function required(path, config) {
	const REQUIRED_MEMO = metadata(path, createMetadataKey(), (ctx) => config?.when ? config.when(ctx) : true);
	metadata(path, REQUIRED, ({ state }) => state.metadata(REQUIRED_MEMO)());
	validate(path, (ctx) => {
		if (ctx.state.metadata(REQUIRED_MEMO)() && isEmpty(ctx.value())) if (config?.error) return getOption(config.error, ctx);
		else return requiredError({ message: getOption(config?.message, ctx) });
	});
}
function validateAsync(path, opts) {
	assertPathIsCurrent(path);
	const pathNode = FieldPathNode.unwrapFieldPath(path);
	const RESOURCE = createManagedMetadataKey((_state, params) => {
		if (opts.debounce !== void 0) {
			const debouncedResource = debounced(() => params(), opts.debounce);
			const wrappedParams = computed(() => chain(debouncedResource), ...ngDevMode ? [{ debugName: "wrappedParams" }] : []);
			return opts.factory(wrappedParams);
		}
		return opts.factory(params);
	});
	RESOURCE[IS_ASYNC_VALIDATION_RESOURCE] = true;
	metadata(path, RESOURCE, (ctx) => {
		const validationState = ctx.stateOf(path).validationState;
		if (validationState.shouldSkipValidation() || !validationState.syncValid()) return;
		if (opts.when && !opts.when(ctx)) return;
		return opts.params(ctx);
	});
	pathNode.builder.addAsyncErrorRule((ctx) => {
		const res = ctx.state.metadata(RESOURCE);
		let errors;
		switch (res.status()) {
			case "idle": return;
			case "loading":
			case "reloading": return "pending";
			case "resolved":
			case "local":
				if (!res.hasValue()) return;
				errors = opts.onSuccess(res.value(), ctx);
				return addDefaultField(errors, ctx.fieldTree);
			case "error":
				errors = opts.onError(res.error(), ctx);
				return addDefaultField(errors, ctx.fieldTree);
		}
	});
}
function validateTree(path, logic) {
	assertPathIsCurrent(path);
	FieldPathNode.unwrapFieldPath(path).builder.addSyncTreeErrorRule((ctx) => addDefaultField(logic(ctx), ctx.fieldTree));
}
function validateStandardSchema(path, schema) {
	const VALIDATOR_MEMO = metadata(path, createMetadataKey(), (ctx) => {
		const resolvedSchema = typeof schema === "function" ? schema(ctx) : schema;
		return resolvedSchema ? resolvedSchema["~standard"].validate(ctx.value()) : void 0;
	});
	validateTree(path, ({ state, fieldTreeOf }) => {
		const result = state.metadata(VALIDATOR_MEMO)();
		if (!result || isPromise(result)) return [];
		return result?.issues?.map((issue) => standardIssueToFormTreeError(fieldTreeOf(path), issue)) ?? [];
	});
	validateAsync(path, {
		params: ({ state }) => {
			const result = state.metadata(VALIDATOR_MEMO)();
			return result && isPromise(result) ? result : void 0;
		},
		factory: (params) => {
			return resource({
				params,
				loader: async ({ params }) => (await params)?.issues ?? []
			});
		},
		onSuccess: (issues, { fieldTreeOf }) => {
			return issues.map((issue) => standardIssueToFormTreeError(fieldTreeOf(path), issue));
		},
		onError: () => {}
	});
}
function standardSchemaError(issue, options) {
	return new StandardSchemaValidationError(issue, options);
}
function standardIssueToFormTreeError(fieldTree, issue) {
	let target = fieldTree;
	for (const pathPart of issue.path ?? []) {
		const pathKey = typeof pathPart === "object" ? pathPart.key : pathPart;
		target = target[pathKey];
	}
	return addDefaultField(standardSchemaError(issue, { message: issue.message }), target);
}
var StandardSchemaValidationError = class extends BaseNgValidationError {
	issue;
	kind = "standardSchema";
	constructor(issue, options) {
		super(options);
		this.issue = issue;
	}
};
function validateHttp(path, opts) {
	validateAsync(path, {
		params: opts.request,
		debounce: opts.debounce,
		factory: (request) => httpResource(request, opts.options),
		onSuccess: opts.onSuccess,
		onError: opts.onError,
		when: opts.when
	});
}
function debounce(path, config) {
	assertPathIsCurrent(path);
	const pathNode = FieldPathNode.unwrapFieldPath(path);
	const debouncer = normalizeDebouncer(config);
	pathNode.builder.addMetadataRule(DEBOUNCER, () => debouncer);
}
function normalizeDebouncer(debouncer) {
	if (typeof debouncer === "function") return debouncer;
	if (debouncer === "blur") return debounceUntilBlur();
	if (debouncer > 0) return debounceForDuration(debouncer);
	return immediate;
}
function debounceForDuration(durationInMilliseconds) {
	return (_context, abortSignal) => {
		return new Promise((resolve) => {
			let timeoutId;
			const onAbort = () => {
				clearTimeout(timeoutId);
				resolve();
			};
			timeoutId = setTimeout(() => {
				abortSignal.removeEventListener("abort", onAbort);
				resolve();
			}, durationInMilliseconds);
			abortSignal.addEventListener("abort", onAbort, { once: true });
		});
	};
}
function debounceUntilBlur() {
	return (_context, abortSignal) => {
		return new Promise((resolve) => {
			abortSignal.addEventListener("abort", () => resolve(), { once: true });
		});
	};
}
function immediate() {}
function createParser(getValue, setValue, parse) {
	const errors = linkedSignal({
		...ngDevMode ? { debugName: "errors" } : {},
		source: getValue,
		computation: () => [],
		equal: shallowArrayEquals
	});
	const setRawValue = (rawValue) => {
		const result = parse(rawValue);
		errors.set(normalizeErrors(result.error));
		if (result.value !== void 0) setValue(result.value);
		errors.set(normalizeErrors(result.error));
	};
	const reset = () => {
		errors.set([]);
	};
	return {
		errors: errors.asReadonly(),
		setRawValue,
		reset
	};
}
function transformedValue(value, options) {
	const { parse, format } = options;
	const parser = createParser(value, value.set, parse);
	const rawValue = linkedSignal(() => format(value()), ...ngDevMode ? [{ debugName: "rawValue" }] : []);
	const result = rawValue;
	result.parseErrors = parser.errors;
	const originalSet = result.set.bind(result);
	const integration = inject(ɵFORM_CONTROL_INTEGRATION, {
		self: true,
		optional: true
	});
	if (integration) {
		integration.setParseErrors(parser.errors);
		integration.onReset = (resetValue) => {
			parser.reset();
			const modelValue = resetValue !== void 0 ? resetValue : value();
			originalSet(format(modelValue));
		};
	}
	result.set = (newRawValue) => {
		parser.setRawValue(newRawValue);
		originalSet(newRawValue);
	};
	result.update = (updateFn) => {
		result.set(updateFn(rawValue()));
	};
	return result;
}
var InteropNgControl = class {
	field;
	constructor(field) {
		this.field = field;
	}
	control = this;
	get value() {
		return this.field().controlValue();
	}
	get valid() {
		return this.field().valid();
	}
	get invalid() {
		return this.field().invalid();
	}
	get pending() {
		return this.field().pending();
	}
	get disabled() {
		return this.field().disabled();
	}
	get enabled() {
		return !this.field().disabled();
	}
	get errors() {
		return signalErrorsToValidationErrors(this.field().errors());
	}
	get pristine() {
		return !this.field().dirty();
	}
	get dirty() {
		return this.field().dirty();
	}
	get touched() {
		return this.field().touched();
	}
	get untouched() {
		return !this.field().touched();
	}
	get status() {
		if (this.field().disabled()) return "DISABLED";
		if (this.field().valid()) return "VALID";
		if (this.field().invalid()) return "INVALID";
		if (this.field().pending()) return "PENDING";
		throw new RuntimeError(1910, ngDevMode && "Unknown form control status");
	}
	valueAccessor = null;
	hasValidator(validator) {
		if (validator === Validators.required) return this.field().required();
		return false;
	}
	updateValueAndValidity() {}
};
var FIELD_STATE_KEY_TO_CONTROL_BINDING = {
	disabled: "disabled",
	disabledReasons: "disabledReasons",
	dirty: "dirty",
	errors: "errors",
	hidden: "hidden",
	invalid: "invalid",
	max: "max",
	maxLength: "maxLength",
	min: "min",
	minLength: "minLength",
	name: "name",
	pattern: "pattern",
	pending: "pending",
	readonly: "readonly",
	required: "required",
	touched: "touched"
};
var CONTROL_BINDING_TO_FIELD_STATE_KEY = /* @__PURE__ */ (() => {
	const map = {};
	for (const key of Object.keys(FIELD_STATE_KEY_TO_CONTROL_BINDING)) map[FIELD_STATE_KEY_TO_CONTROL_BINDING[key]] = key;
	return map;
})();
function readFieldStateBindingValue(fieldState, key) {
	return fieldState[CONTROL_BINDING_TO_FIELD_STATE_KEY[key]]?.();
}
var CONTROL_BINDING_NAMES = /* @__PURE__ */ (() => Object.values(FIELD_STATE_KEY_TO_CONTROL_BINDING))();
function createBindings() {
	return {};
}
function bindingUpdated(bindings, key, value) {
	if (bindings[key] !== value) {
		bindings[key] = value;
		return true;
	}
	return false;
}
function getNativeControlValue(element, currentValue, validityMonitor) {
	let modelValue;
	if (isInput(element) && validityMonitor.isBadInput(element)) return { error: new NativeInputParseError() };
	switch (element.type) {
		case "checkbox": return { value: element.checked };
		case "number":
		case "range":
		case "datetime-local":
			modelValue = untracked(currentValue);
			if (typeof modelValue === "number" || modelValue === null) return { value: element.value === "" ? null : element.valueAsNumber };
			break;
		case "date":
		case "month":
		case "time":
		case "week":
			modelValue = untracked(currentValue);
			if (modelValue === null || modelValue instanceof Date) return { value: element.valueAsDate };
			else if (typeof modelValue === "number") return { value: element.valueAsNumber };
			break;
	}
	if (element.tagName === "INPUT" && element.type === "text") {
		modelValue ??= untracked(currentValue);
		if (typeof modelValue === "number" || modelValue === null) {
			if (element.value === "") return { value: null };
			const parsed = Number(element.value);
			if (Number.isNaN(parsed)) return { error: new NativeInputParseError() };
			return { value: parsed };
		}
	}
	return { value: element.value };
}
function setNativeControlValue(element, value) {
	switch (element.type) {
		case "checkbox":
			element.checked = value;
			return;
		case "radio":
			element.checked = value === element.value;
			return;
		case "number":
		case "range":
		case "datetime-local":
			if (typeof value === "number") {
				setNativeNumberControlValue(element, value);
				return;
			} else if (value === null) {
				element.value = "";
				return;
			}
			break;
		case "date":
		case "month":
		case "time":
		case "week": if (value === null || value instanceof Date) {
			element.valueAsDate = value;
			return;
		} else if (typeof value === "number") {
			setNativeNumberControlValue(element, value);
			return;
		}
	}
	if (element.tagName === "INPUT" && element.type === "text") {
		if (typeof value === "number") {
			element.value = isNaN(value) ? "" : String(value);
			return;
		}
		if (value === null) {
			if (typeof ngDevMode !== "undefined" && ngDevMode) console.warn(formatRuntimeError(1921, `The text input ${element.name} received a null value. Text inputs should use empty strings to represent null values.  The input's value will be set to an empty string instead.`));
			element.value = "";
			return;
		}
	}
	element.value = value;
}
function setNativeNumberControlValue(element, value) {
	if (isNaN(value)) element.value = "";
	else element.valueAsNumber = value;
}
function isInput(element) {
	return element.tagName === "INPUT";
}
function inputRequiresValidityTracking(input) {
	return input.type === "date" || input.type === "datetime-local" || input.type === "month" || input.type === "time" || input.type === "week";
}
function formatDateForInput(date, type) {
	const year = date.getUTCFullYear();
	const month = String(date.getUTCMonth() + 1).padStart(2, "0");
	if (type === "month") return `${year}-${month}`;
	return `${year}-${month}-${String(date.getUTCDate()).padStart(2, "0")}`;
}
function formatDateForMinMax(name, value, type) {
	if (value instanceof Date && (name === "min" || name === "max") && (type === "date" || type === "month")) return formatDateForInput(value, type);
	return value;
}
function customControlCreate(host, parent) {
	host.listenToCustomControlModel((value) => parent.state().controlValue.set(value));
	host.listenToCustomControlOutput("touch", () => parent.state().markAsTouched());
	parent.registerAsBinding(host.customControl);
	const bindings = createBindings();
	return () => {
		const state = parent.state();
		const controlValue = state.controlValue();
		if (bindingUpdated(bindings, "controlValue", controlValue)) host.setCustomControlModelInput(controlValue);
		for (const name of CONTROL_BINDING_NAMES) {
			let value;
			if (name === "errors") value = parent.errors();
			else value = readFieldStateBindingValue(state, name);
			if (bindingUpdated(bindings, name, value)) {
				host.setInputOnDirectives(name, value);
				if (parent.elementAcceptsNativeProperty(name) && !host.customControlHasInput(name)) {
					const domValue = formatDateForMinMax(name, value, parent.nativeFormElement.type);
					setNativeDomProperty(parent.renderer, parent.nativeFormElement, name, domValue);
				}
			}
		}
	};
}
function isValidatorObject(v) {
	return typeof v === "object" && v !== null;
}
function cvaControlCreate(host, parent) {
	const bindings = createBindings();
	parent.controlValueAccessor.registerOnChange((value) => {
		bindings["controlValue"] = value;
		parent.state().controlValue.set(value);
	});
	parent.controlValueAccessor.registerOnTouched(() => parent.state().markAsTouched());
	const legacyValidators = parent.injector.get(NG_VALIDATORS, null, {
		optional: true,
		self: true
	});
	if (legacyValidators) {
		let version;
		for (const v of legacyValidators) if (isValidatorObject(v) && v.registerOnValidatorChange) {
			version ??= signal(0);
			v.registerOnValidatorChange(() => {
				version.update((n) => n + 1);
			});
		}
		const validatorFns = legacyValidators.map((v) => typeof v === "function" ? v : v.validate.bind(v));
		const mergedValidator = Validators.compose(validatorFns);
		const parseErrors = computed(() => {
			version?.();
			return reactiveErrorsToSignalErrors(mergedValidator ? mergedValidator(parent.interopNgControl.control) : null, parent.interopNgControl.control);
		}, ...ngDevMode ? [{ debugName: "parseErrors" }] : []);
		parent.parseErrorsSource.set(parseErrors);
	}
	parent.registerAsBinding({ reset: () => {
		const value = parent.state().value();
		bindings["controlValue"] = value;
		untracked(() => parent.controlValueAccessor.writeValue(value));
	} });
	return () => {
		const fieldState = parent.state();
		const controlValue = fieldState.controlValue();
		if (bindingUpdated(bindings, "controlValue", controlValue)) untracked(() => parent.controlValueAccessor.writeValue(controlValue));
		for (const name of CONTROL_BINDING_NAMES) {
			const value = readFieldStateBindingValue(fieldState, name);
			if (bindingUpdated(bindings, name, value)) {
				const propertyWasSet = host.setInputOnDirectives(name, value, name === "name" ? isDefinedPredicate : void 0);
				if (name === "disabled" && parent.controlValueAccessor.setDisabledState) untracked(() => parent.controlValueAccessor.setDisabledState(value));
				else if (!propertyWasSet && parent.elementAcceptsNativeProperty(name)) setNativeDomProperty(parent.renderer, parent.nativeFormElement, name, value);
			}
		}
	};
}
function isDefinedPredicate(value) {
	return value == null;
}
function observeSelectMutations(select, onMutation, destroyRef) {
	if (typeof MutationObserver !== "function") return;
	const observer = new MutationObserver((mutations) => {
		if (mutations.some((m) => isRelevantSelectMutation(m))) onMutation();
	});
	observer.observe(select, {
		attributes: true,
		attributeFilter: ["value"],
		characterData: true,
		childList: true,
		subtree: true
	});
	destroyRef.onDestroy(() => observer.disconnect());
}
function isRelevantSelectMutation(mutation) {
	if (mutation.type === "childList" || mutation.type === "characterData") {
		if (mutation.target instanceof Comment) return false;
		for (const node of mutation.addedNodes) if (!(node instanceof Comment)) return true;
		for (const node of mutation.removedNodes) if (!(node instanceof Comment)) return true;
		return false;
	}
	if (mutation.type === "attributes" && mutation.target instanceof HTMLOptionElement) return true;
	return false;
}
function nativeControlCreate(host, parent, parseErrorsSource, validityMonitor) {
	let updateMode = false;
	const input = parent.nativeFormElement;
	const parser = createParser(() => parent.state().value(), (rawValue) => parent.state().controlValue.set(rawValue), (_rawValue) => getNativeControlValue(input, parent.state().value, validityMonitor));
	parseErrorsSource.set(parser.errors);
	parent.onReset = () => {
		parser.reset();
		const value = parent.state().value();
		bindings["controlValue"] = value;
		setNativeControlValue(input, value);
	};
	host.listenToDom("input", () => parser.setRawValue(void 0));
	host.listenToDom("blur", () => parent.state().markAsTouched());
	if (isInput(input) && inputRequiresValidityTracking(input)) validityMonitor.watchValidity(parent.destroyRef, input, () => parser.setRawValue(void 0));
	parent.registerAsBinding();
	if (input.tagName === "SELECT") observeSelectMutations(input, () => {
		if (!updateMode) return;
		input.value = parent.state().controlValue();
	}, parent.destroyRef);
	const bindings = createBindings();
	return () => {
		const state = parent.state();
		for (const name of CONTROL_BINDING_NAMES) {
			const value = readFieldStateBindingValue(state, name);
			if (bindingUpdated(bindings, name, value)) {
				host.setInputOnDirectives(name, value);
				if (parent.elementAcceptsNativeProperty(name)) {
					const domValue = formatDateForMinMax(name, value, input.type);
					setNativeDomProperty(parent.renderer, input, name, domValue);
				}
			}
		}
		const controlValue = state.controlValue();
		const controlValueChanged = bindingUpdated(bindings, "controlValue", controlValue);
		const radioValueChanged = input.type === "radio" && bindingUpdated(bindings, "radioValue", input.value);
		if (controlValueChanged || radioValueChanged) setNativeControlValue(input, controlValue);
		updateMode = true;
	};
}
var InputValidityMonitor = class InputValidityMonitor {
	static ɵfac = function InputValidityMonitor_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || InputValidityMonitor)();
	};
	static ɵprov = /* @__PURE__ */ ɵɵdefineInjectable({
		token: InputValidityMonitor,
		factory: (__ngFactoryType__) => AnimationInputValidityMonitor.ɵfac(__ngFactoryType__),
		providedIn: "root"
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(InputValidityMonitor, [{
		type: Injectable,
		args: [{
			providedIn: "root",
			useClass: forwardRef(() => AnimationInputValidityMonitor)
		}]
	}], null, null);
})();
var AnimationInputValidityMonitor = class AnimationInputValidityMonitor extends InputValidityMonitor {
	document = inject(DOCUMENT);
	cspNonce = inject(CSP_NONCE, { optional: true });
	injectedStyles = /* @__PURE__ */ new WeakMap();
	watchValidity(destroyRef, element, callback) {
		const rootNode = element.getRootNode();
		if (!this.injectedStyles.has(rootNode)) this.injectedStyles.set(rootNode, this.createTransitionStyle(rootNode));
		const onAnimationStart = (event) => {
			const animationEvent = event;
			if (animationEvent.animationName === "ng-valid" || animationEvent.animationName === "ng-invalid") callback();
		};
		element.addEventListener("animationstart", onAnimationStart);
		destroyRef.onDestroy(() => {
			element.removeEventListener("animationstart", onAnimationStart);
		});
	}
	isBadInput(element) {
		return element.validity?.badInput ?? false;
	}
	createTransitionStyle(rootNode) {
		const element = this.document.createElement("style");
		if (this.cspNonce) element.nonce = this.cspNonce;
		element.textContent = `
      @keyframes ng-valid {}
      @keyframes ng-invalid {}
      input:valid, textarea:valid {
        animation: ng-valid 0.001s;
      }
      input:invalid, textarea:invalid {
        animation: ng-invalid 0.001s;
      }
    `;
		if (rootNode.nodeType === 9) rootNode.head?.appendChild(element);
		else rootNode.appendChild(element);
		return element;
	}
	ngOnDestroy() {
		this.injectedStyles.get(this.document)?.remove();
	}
	static ɵfac = /* @__PURE__ */ (() => {
		let ɵAnimationInputValidityMonitor_BaseFactory;
		return function AnimationInputValidityMonitor_Factory(__ngFactoryType__) {
			return (ɵAnimationInputValidityMonitor_BaseFactory || (ɵAnimationInputValidityMonitor_BaseFactory = ɵɵgetInheritedFactory(AnimationInputValidityMonitor)))(__ngFactoryType__ || AnimationInputValidityMonitor);
		};
	})();
	static ɵprov = /* @__PURE__ */ ɵɵdefineInjectable({
		token: AnimationInputValidityMonitor,
		factory: AnimationInputValidityMonitor.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AnimationInputValidityMonitor, [{ type: Injectable }], null, null);
})();
var ɵNgFieldDirective = Symbol();
var FORM_FIELD = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "FORM_FIELD" : "");
var FormField = class FormField {
	field = input.required({
		...ngDevMode ? { debugName: "field" } : {},
		alias: "formField"
	});
	state = computed(() => this.field()(), ...ngDevMode ? [{ debugName: "state" }] : []);
	renderer = inject(Renderer2);
	destroyRef = inject(DestroyRef);
	injector = inject(Injector);
	element = inject(ElementRef).nativeElement;
	elementIsNativeFormElement = isNativeFormElement(this.element);
	elementAcceptsTextualValues = isTextualFormElement(this.element);
	_elementAcceptsMinMax;
	nativeFormElement = this.elementIsNativeFormElement ? this.element : void 0;
	focuser = (options) => this.element.focus(options);
	controlValueAccessors = inject(NG_VALUE_ACCESSOR, {
		optional: true,
		self: true
	});
	config = inject(SIGNAL_FORMS_CONFIG, { optional: true });
	validityMonitor = inject(InputValidityMonitor);
	parseErrorsSource = signal(void 0, ...ngDevMode ? [{ debugName: "parseErrorsSource" }] : []);
	_interopNgControl;
	get interopNgControl() {
		return this._interopNgControl ??= new InteropNgControl(this.state);
	}
	parseErrors = computed(() => this.parseErrorsSource()?.().map((err) => ({
		...err,
		fieldTree: untracked(this.state).fieldTree,
		formField: this
	})) ?? [], {
		...ngDevMode ? { debugName: "parseErrors" } : {},
		equal: shallowArrayEquals
	});
	errors = computed(() => this.state().errors().filter((err) => !err.formField || err.formField === this), {
		...ngDevMode ? { debugName: "errors" } : {},
		equal: shallowArrayEquals
	});
	isFieldBinding = false;
	resetter = () => {};
	parseErrorsResetCallback;
	setParseErrors(source) {
		this.parseErrorsSource.set(source);
	}
	set onReset(callback) {
		this.parseErrorsResetCallback = callback;
	}
	get onReset() {
		return this.parseErrorsResetCallback;
	}
	get controlValueAccessor() {
		if (!this.controlValueAccessors || this.controlValueAccessors.length === 0) return this.interopNgControl?.valueAccessor ?? void 0;
		return selectValueAccessor(this.interopNgControl, this.controlValueAccessors) ?? void 0;
	}
	installClassBindingEffect() {
		const classes = Object.entries(this.config?.classes ?? {}).map(([className, computation]) => [className, computed(() => computation(this))]);
		if (classes.length === 0) return;
		const bindings = createBindings();
		afterRenderEffect({ write: () => {
			for (const [className, computation] of classes) {
				const active = computation();
				if (bindingUpdated(bindings, className, active)) if (active) this.renderer.addClass(this.element, className);
				else this.renderer.removeClass(this.element, className);
			}
		} }, { injector: this.injector });
	}
	focus(options) {
		this.focuser(options);
	}
	reset() {
		this.resetter();
		this.parseErrorsResetCallback?.(this.state().value());
	}
	registerAsBinding(bindingOptions) {
		if (this.isFieldBinding) throw new RuntimeError(1913, typeof ngDevMode !== "undefined" && ngDevMode && "FormField already registered as a binding");
		this.isFieldBinding = true;
		this.installClassBindingEffect();
		if (bindingOptions?.focus) this.focuser = (focusOptions) => bindingOptions.focus(focusOptions);
		if (bindingOptions?.reset) this.resetter = () => bindingOptions.reset();
		effect((onCleanup) => {
			const fieldNode = this.state();
			fieldNode.nodeState.formFieldBindings.update((controls) => [...controls, this]);
			onCleanup(() => {
				fieldNode.nodeState.formFieldBindings.update((controls) => controls.filter((c) => c !== this));
			});
		}, { injector: this.injector });
		if (typeof ngDevMode !== "undefined" && ngDevMode) effect(() => {
			const fieldNode = this.state();
			if (fieldNode.hidden()) {
				const path = fieldNode.structure.pathKeys().join(".") || "<root>";
				console.warn(formatRuntimeError(1916, `Field '${path}' is hidden but is being rendered. Hidden fields should be removed from the DOM using @if.`));
			}
		}, { injector: this.injector });
	}
	[ɵNgFieldDirective];
	ɵngControlCreate(host) {
		if (host.hasPassThrough) return;
		if (this.controlValueAccessor) this.ɵngControlUpdate = cvaControlCreate(host, this);
		else if (host.customControl) this.ɵngControlUpdate = customControlCreate(host, this);
		else if (this.elementIsNativeFormElement) this.ɵngControlUpdate = nativeControlCreate(host, this, this.parseErrorsSource, this.validityMonitor);
		else throw new RuntimeError(1914, typeof ngDevMode !== "undefined" && ngDevMode && `${host.descriptor} is an invalid [formField] directive host. The host must be a native form control (such as <input>', '<select>', or '<textarea>') or a custom form control with a 'value' or 'checked' model.`);
	}
	ɵngControlUpdate;
	elementAcceptsNativeProperty(key) {
		if (!this.elementIsNativeFormElement) return false;
		switch (key) {
			case "min":
			case "max": return this._elementAcceptsMinMax ??= elementAcceptsMinMax(this.element);
			case "minLength":
			case "maxLength": return this.elementAcceptsTextualValues;
			case "disabled":
			case "required":
			case "readonly":
			case "name": return true;
			default: return false;
		}
	}
	static ɵfac = function FormField_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || FormField)();
	};
	static ɵdir = /* @__PURE__ */ ɵɵdefineDirective({
		type: FormField,
		selectors: [[
			"",
			"formField",
			""
		]],
		inputs: { field: [
			1,
			"formField",
			"field"
		] },
		exportAs: ["formField"],
		features: [ɵɵProvidersFeature([
			{
				provide: FORM_FIELD,
				useExisting: FormField
			},
			{
				provide: NgControl,
				useFactory: () => inject(FormField).interopNgControl
			},
			{
				provide: ɵFORM_CONTROL_INTEGRATION,
				useFactory: () => inject(FORM_FIELD, { self: true })
			}
		]), ɵɵControlFeature("formField")]
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormField, [{
		type: Directive,
		args: [{
			selector: "[formField]",
			exportAs: "formField",
			providers: [
				{
					provide: FORM_FIELD,
					useExisting: FormField
				},
				{
					provide: NgControl,
					useFactory: () => inject(FormField).interopNgControl
				},
				{
					provide: ɵFORM_CONTROL_INTEGRATION,
					useFactory: () => inject(FORM_FIELD, { self: true })
				}
			]
		}]
	}], null, { field: [{
		type: Input,
		args: [{
			isSignal: true,
			alias: "formField",
			required: true
		}]
	}] });
})();
var FormRoot = class FormRoot {
	fieldTree = input.required({
		...ngDevMode ? { debugName: "fieldTree" } : {},
		alias: "formRoot"
	});
	onSubmit(event) {
		event.preventDefault();
		untracked(() => {
			const fieldTree = this.fieldTree();
			if (fieldTree().structure.fieldManager.submitOptions) submit(fieldTree);
		});
	}
	static ɵfac = function FormRoot_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || FormRoot)();
	};
	static ɵdir = /* @__PURE__ */ ɵɵdefineDirective({
		type: FormRoot,
		selectors: [[
			"form",
			"formRoot",
			""
		]],
		hostAttrs: ["novalidate", ""],
		hostBindings: function FormRoot_HostBindings(rf, ctx) {
			if (rf & 1) ɵɵlistener("submit", function FormRoot_submit_HostBindingHandler($event) {
				return ctx.onSubmit($event);
			});
		},
		inputs: { fieldTree: [
			1,
			"formRoot",
			"fieldTree"
		] }
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormRoot, [{
		type: Directive,
		args: [{
			selector: "form[formRoot]",
			host: {
				"novalidate": "",
				"(submit)": "onSubmit($event)"
			}
		}]
	}], null, { fieldTree: [{
		type: Input,
		args: [{
			isSignal: true,
			alias: "formRoot",
			required: true
		}]
	}] });
})();
var registerWebMcpForm = (formTree, options) => {
	const injector = inject(Injector);
	return new Promise((resolve, reject) => {
		effect(() => {
			untracked(() => {
				initWebMcpForm(formTree, options, injector).then(resolve, reject);
			});
		});
	});
};
async function initWebMcpForm(formTree, options, injector) {
	const node = formTree();
	const inputSchema = inferSchemaFromFieldNode(node);
	if (!inputSchema) throw new Error(`Could not accurately infer WebMCP schema for form "${options.name}". Ensure that the form model does not contain null, undefined, empty arrays, or unsupported types.`);
	await declareExperimentalWebMcpTool({
		name: options.name,
		description: options.description,
		inputSchema,
		execute: async (args) => {
			node.value.set(args);
			if (await submit(formTree)) return { content: [{
				type: "text",
				text: "Form submitted successfully."
			}] };
			else return { content: [{
				type: "text",
				text: `Form submission failed:\n${node.errorSummary().map((err) => {
					const fieldName = err.fieldTree().structure.pathKeys().join(".");
					return `${fieldName ? `${fieldName}: ` : ""}${err.message || err.kind}`;
				}).join("\n")}`
			}] };
		}
	}, injector);
}
function inferSchemaFromFieldNode(node) {
	const value = node.value();
	if (typeof value === "string") return { type: "string" };
	if (typeof value === "number") return { type: "number" };
	if (typeof value === "boolean") return { type: "boolean" };
	if (value === null || value === void 0) return void 0;
	if (Array.isArray(value)) {
		if (value.length === 0) return void 0;
		const firstChild = node.structure.getChild("0");
		if (!firstChild) return void 0;
		const itemSchema = inferSchemaFromFieldNode(firstChild);
		if (!itemSchema) return void 0;
		return {
			type: "array",
			items: itemSchema
		};
	}
	if (typeof value === "object") {
		const properties = {};
		const required = [];
		const children = node.structure.children();
		for (const child of children) {
			const key = child.keyInParent();
			const childSchema = inferSchemaFromFieldNode(child);
			if (!childSchema) return void 0;
			properties[key] = childSchema;
			if (child.required()) required.push(key.toString());
		}
		return {
			type: "object",
			properties,
			required,
			additionalProperties: false
		};
	}
}
function provideExperimentalWebMcpForms() {
	return makeEnvironmentProviders([{
		provide: REGISTER_WEBMCP_FORM,
		useValue: registerWebMcpForm
	}]);
}
//#endregion
export { BaseNgValidationError, EmailValidationError, FORM_FIELD, FormField, FormRoot, IS_ASYNC_VALIDATION_RESOURCE, MAX, MAX_DATE, MAX_LENGTH, MAX_NUMBER, MIN, MIN_DATE, MIN_LENGTH, MIN_NUMBER, MaxDateValidationError, MaxLengthValidationError, MaxValidationError, MetadataKey, MetadataReducer, MinDateValidationError, MinLengthValidationError, MinValidationError, NativeInputParseError, NgValidationError, PATTERN, PatternValidationError, REQUIRED, RequiredValidationError, StandardSchemaValidationError, apply, applyEach, applyWhen, applyWhenValue, createLimitSelectionKey, createManagedMetadataKey, createMetadataKey, debounce, disabled, email, emailError, form, hidden, isFieldTree, max, maxDate, maxDateError, maxError, maxLength, maxLengthError, metadata, min, minDate, minDateError, minError, minLength, minLengthError, pattern, patternError, provideExperimentalWebMcpForms, provideSignalFormsConfig, readonly, required, requiredError, schema, standardSchemaError, submit, transformedValue, validate, validateAsync, validateHttp, validateStandardSchema, validateTree, ɵNgFieldDirective };
