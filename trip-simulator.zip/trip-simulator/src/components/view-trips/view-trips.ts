import { Component, inject, OnInit, signal } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Trips } from '../trips';
import { Trip } from '../create-trip-form/create-trip-form.model';
import { EachTrip } from '../each-trip/each-trip';
import { finalize, Subscription } from 'rxjs';

@Component({
  imports: [EachTrip],
  selector: 'app-view-trips',
  styleUrl: './view-trips.css',
  templateUrl: './view-trips.html',
})
export class ViewTrips {
  private tripService = inject(Trips);

  trips = signal<Trip[]>([]);
  isTripsLoading = signal<boolean>(false);

  getAllTripsSubscription: Subscription;

  onGetAllTrips() {
    this.getAllTripsSubscription?.unsubscribe();
    this.isTripsLoading.set(true);
    this.tripService
      .getAllTrips()
      .pipe(finalize(() => this.isTripsLoading.set(false)))
      .subscribe((allTrips) => {
        this.trips.set(allTrips);
      });
  }

  ngOnInit() {
    this.onGetAllTrips();
  }
}
