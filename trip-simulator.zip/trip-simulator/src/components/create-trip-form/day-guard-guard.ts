import { CanActivateFn, Router } from '@angular/router';
import { inject } from '@angular/core';
import { Trips } from '../trips';
import { catchError, map, of } from 'rxjs';

export const dayGuard: CanActivateFn = (route, state) => {
  const tripId = route.params['tripId'];
  const day = Number(route.paramMap.get('day'));

  const tripService = inject(Trips);
  const router = inject(Router);

  if (Number.isNaN(day)) {
    return router.createUrlTree(['trips', tripId]);
  }

  return tripService.getTrip(tripId).pipe(
    map((trip) => {
      if (day > trip.days) {
        return router.createUrlTree(['trips', tripId]);
      } else {
        return true;
      }
    }),
    catchError((err) => {
      console.log("Error from guard: ",err);
      return router.navigate(['trips']);
    })
  );
};

