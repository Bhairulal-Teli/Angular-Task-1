export interface Trip {
  id: string;
  name: string;
  source: string;
  destination: string;
  distance: number;
  days: number;
  startDate: string;
  endDate: string;
}


export interface DayData {
  tripId: string;
  day: number;
  morning: string;
  afternoon: string;
  evening: string;
  night: string;
}


