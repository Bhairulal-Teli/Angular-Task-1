import { Component, computed, effect, inject, input, signal } from '@angular/core';
import {
  AbstractControl,
  AsyncValidatorFn,
  FormArray,
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  ValidationErrors,
  Validators,
} from '@angular/forms';
import dayjs from 'dayjs';
import { Trips } from '../trips';
import { DayData, Trip } from './create-trip-form.model';
import { TripControl } from './trip-control/trip-control';
import { TripDayControl } from './trip-day-control/trip-day-control';
import { Router } from '@angular/router';
import { map, Subscription } from 'rxjs';

const timeSchedule = ['morning', 'afternoon', 'evening', 'night'];

type ScheduleControl = FormGroup<{
  type: FormControl<'morning' | 'afternoon' | 'evening' | 'night'>;
  checkBoxState: FormControl<boolean>;
  textAreaValue: FormControl<string>;
  day: FormControl<number>;
}>;

type EditTripDays = {
  type: 'morning' | 'afternoon' | 'evening' | 'night';
  checkBoxState: boolean;
  textAreaValue: string;
  day: number;
};

export type FormTripData = {
  name: FormControl<string | null>;
  source: FormControl<string | null>;
  destination: FormControl<string | null>;
  startDate: FormControl<string | null>;
  endDate: FormControl<string | null>;
  days: FormControl<number | null>;
  distance: FormControl<number | null>;
  daysData: FormArray<ScheduleControl>;
};

interface PayLoadForDay {
  tripId: string;
  day: number;
  morning: string;
  afternoon: string;
  evening: string;
  night: string;
}

@Component({
  imports: [ReactiveFormsModule, TripControl, TripDayControl],
  standalone: true,
  selector: 'app-create-trip-form',
  styleUrl: './create-trip-form.css',
  templateUrl: './create-trip-form.html',
})
export class CreateTripForm {
  tripId = input<string>();

  private tripService = inject(Trips);
  private router = inject(Router);

  isFormSubmitting = signal<boolean>(false);

  tripForm = new FormGroup({
    name: new FormControl('', Validators.required),
    source: new FormControl('', Validators.required),
    destination: new FormControl('', {
      validators: [Validators.required],
      asyncValidators: [this.repeatTripValidator()],
      updateOn: 'blur',
    }),
    startDate: new FormControl('', Validators.required),
    endDate: new FormControl({ value: '', disabled: true }),
    days: new FormControl(1, [Validators.required, Validators.min(1)]),
    distance: new FormControl(0, Validators.required),
    daysData: new FormArray<ScheduleControl>([]),
  });

  noOfDays = signal(this.tripForm.controls.days.value);

  createSchedule(
    type: 'morning' | 'afternoon' | 'evening' | 'night',
    currentDay: number,
  ): ScheduleControl {
    return new FormGroup({
      type: new FormControl({ value: type, disabled: true }),
      checkBoxState: new FormControl(false),
      textAreaValue: new FormControl({ value: 'Rest', disabled: true }),
      day: new FormControl({ value: currentDay, disabled: true }),
    });
  }

  repeatTripValidator(): AsyncValidatorFn {
    return (control: AbstractControl) => {
      let isRepeat = false;
      const sourceControl = control.parent?.get('source');
      return this.tripService.getAllTrips().pipe(
        map((value: Trip[]) => {
          value.forEach((el: Trip) => {
            if (el.source === sourceControl?.value && el.destination === control.value) {
              isRepeat = true;
            }
          });
          if (isRepeat) return { repeatTripError: 'This trip already exists.' } as ValidationErrors;
          else return null;
        }),
      );
    };
  }

  onFormDayChange() {
    const controlsLen = this.tripForm.controls.daysData.controls.length;

    for (let i = 0; i < controlsLen; i++) {
      this.tripForm.controls.daysData.controls.pop();
    }

    for (let i = 0; i < this.tripForm.controls.days.value!; i++) {
      let schedules = ['morning', 'afternoon', 'evening', 'night'];
      for (let schedule of schedules) {
        this.tripForm.controls.daysData.controls.push(
          this.createSchedule(schedule as 'morning' | 'afternoon' | 'evening' | 'night', i + 1),
        );
      }
    }
  }

  onDateChange() {
    let startDate = this.tripForm.controls.startDate.value!;
    let noOfDays = this.tripForm.controls.days.value!;
    if (startDate !== '' && noOfDays > 0) {
      const date = dayjs(startDate);
      let calculateEndDate = date.add(noOfDays, 'day').format('YYYY-MM-DD').toString();
      this.tripForm.controls.endDate.setValue(calculateEndDate);
    }
  }

  onScheduleControlChange(index: number) {
    const FormArray = this.tripForm.get('daysData') as FormArray;
    const scheduleTextArea = FormArray.at(index).get('textAreaValue');
    const scheduleState: boolean = FormArray.at(index).get('checkBoxState').value;

    if (scheduleState) {
      scheduleTextArea.enable();
      scheduleTextArea.addValidators([Validators.required]);
    } else {
      scheduleTextArea.disable();
      scheduleTextArea.clearValidators();
    }
  }

  isScheduleFormArrayValid = signal<boolean>(true);

  onScheduleTextChange(index: number) {
    this.isScheduleFormArrayValid.set(true);

    const formArray = this.tripForm.get('daysData') as FormArray;
    const checkBoxStateControl = formArray.at(index).get('checkBoxState');
    const textAreaValue = formArray.at(index).get('textAreaValue').value;

    if (textAreaValue === '') {
      checkBoxStateControl.disable();
    } else {
      checkBoxStateControl.enable();
    }

    for (let control of formArray.controls) {
      if (control.status === 'INVALID') {
        this.isScheduleFormArrayValid.set(false);
        break;
      }
    }
  }

  ngOnInit() {
    if (this.tripId() !== undefined) {
      this.setFormValues();
    } else {
      this.onFormDayChange();
    }
  }

  setFormValues() {
    this.tripService.getTripAndDays(this.tripId()).subscribe((tripData) => {
      this.tripForm.setValue({
        name: tripData.trip.name,
        source: tripData.trip.source,
        destination: tripData.trip.destination,
        startDate: tripData.trip.startDate,
        endDate: tripData.trip.endDate,
        days: tripData.trip.days,
        distance: tripData.trip.distance,
        daysData: tripData.days.map((day) => {
          ['morning', 'afternoon', 'evening', 'night'].forEach(time => {
            {
              day: day.day,
              type: time,
              checkBoxState: false,
              textAreaValue: day[time as 'morning' | 'afternoon' | 'evening' | 'night'],
            };
          })
        }),
      })
    })
  }



  addTripDataSubscription: Subscription;
  onSubmitForm() {
    this.addTripDataSubscription?.unsubscribe();
    // console.log(this.tripForm.controls.daysData.status);
    this.isFormSubmitting.set(true);

    let tripControl = this.tripForm.controls;
    let daysControl = tripControl.daysData.controls;

    let customId = (Math.random() * 100).toString();
    const safeEndDate =
      tripControl.endDate.value === '' ? tripControl.startDate.value : tripControl.endDate.value;

    let tripData: Trip = {
      id: customId,
      name: tripControl.name.value!,
      source: tripControl.source.value!,
      destination: tripControl.destination.value!,
      distance: tripControl.distance.value!,
      days: tripControl.days.value!,
      startDate: tripControl.startDate.value!,
      endDate: safeEndDate!,
    };

    const days: PayLoadForDay[] = [];

    for (let i = 0; i < tripControl.days.value; i++) {
      days.push({
        day: 0,
        tripId: 'no-need',
        morning: 'rest',
        afternoon: 'rest',
        evening: 'rest',
        night: 'rest',
      });
    }

    let index = 0;

    for (let timeControl of daysControl.values()) {
      days[Math.floor(index / 4)].day = timeControl.controls.day.value;
      days[Math.floor(index / 4)][timeControl.controls.type.value] =
        timeControl.controls.textAreaValue.value;
      index++;
    }

    this.addTripDataSubscription = this.tripService.addTrip(tripData, days).subscribe({
      next: (res) => {
        this.isFormSubmitting.set(false);
        this.router.navigate(['trips']).then(() => console.log('successfully navigated to trips'));
      },
      error: (error) => {
        this.isFormSubmitting.set(false);
        console.log(error);
      },
    });
  }

  ngOnDestroy() {
    this.addTripDataSubscription?.unsubscribe();
  }
}
