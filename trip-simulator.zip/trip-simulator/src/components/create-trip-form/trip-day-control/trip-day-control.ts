import { Component, input } from '@angular/core';
import { FormControl, ReactiveFormsModule } from '@angular/forms';

@Component({
  imports: [ReactiveFormsModule],
  selector: 'app-trip-day-control',
  styleUrl: './trip-day-control.css',
  templateUrl: './trip-day-control.html',
})
export class TripDayControl {
  dayFormCheckBoxControl = input.required<FormControl>();
  dayFormTextAreaControl = input.required<FormControl>();
  dayDetailsErrorControl = input.required<FormControl>();
  dayTime = input.required<string>();

}
