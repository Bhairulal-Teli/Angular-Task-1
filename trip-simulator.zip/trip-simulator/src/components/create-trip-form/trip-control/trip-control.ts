import { Component, ElementRef, inject, input, output } from '@angular/core';
import { FormControl, ReactiveFormsModule } from '@angular/forms';

@Component({
  imports: [ReactiveFormsModule],
  selector: 'app-trip-control',
  styleUrl: './trip-control.css',
  templateUrl: './trip-control.html',
})
export class TripControl {
  tripFormControl = input.required<FormControl>();
  controlName = input.required<string>();
  controlType = input.required<string>();
}
