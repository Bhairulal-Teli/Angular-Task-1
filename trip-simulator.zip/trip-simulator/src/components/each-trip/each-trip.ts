import { Component, input, output, signal } from '@angular/core';
import { Trip } from '../create-trip-form/create-trip-form.model';
import { DatePipe } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  imports: [DatePipe, RouterLink],
  selector: 'app-each-trip',
  styleUrl: './each-trip.css',
  templateUrl: './each-trip.html',
})
export class EachTrip {
  trip = input.required<Trip>();
  isInsideTripListings = input.required<boolean>();

  edit = output();
  delete = output()

  onEditTrip() {
    this.edit.emit();
  }

  onDeleteTrip() {
    this.delete.emit();
  }
}
