import { Component } from '@angular/core';
import { CdkDrag, CdkDragDrop, CdkDropList, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';

@Component({
  imports: [CdkDrag, CdkDropList],
  selector: 'app-drag-and-drop',
  styleUrl: './drag-and-drop.css',
  templateUrl: './drag-and-drop.html',
})
export class DragAndDrop {
  // movies = [
  //   'Episode I - The Phantom Menace',
  //   'Episode II - Attack of the Clones',
  //   'Episode III - Revenge of the Sith',
  //   'Episode IV - A New Hope',
  //   'Episode V - The Empire Strikes Back',
  //   'Episode VI - Return of the Jedi',
  //   'Episode VII - The Force Awakens',
  //   'Episode VIII - The Last Jedi',
  //   'Episode IX - The Rise of Skywalker',
  // ];
  // drop(event: CdkDragDrop<string[]>) {
  //   moveItemInArray(this.movies, event.previousIndex, event.currentIndex);
  // }

  goodMovies = <Array<string>>['Avengers: EndGame', 'Avatar', 'Thor: Ragnorok', 'Red Notice', 'Jumanji'];
  averageMovies = <Array<string>>['Black Widow', 'Thunderbolts', 'Godzilla vs Kong', 'Thor: Love and Thunder', 'Spiderman: Far from Home'];

  drop(event: CdkDragDrop<string[]>) {
    if(event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    } else {
      transferArrayItem(
        event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex,
      )
    }
  }
}
