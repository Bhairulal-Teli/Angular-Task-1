import { Component, ElementRef, inject, input, signal } from '@angular/core';
import { ActivatedRoute, Router, RouterLink, RouterOutlet } from '@angular/router';
import { Trip } from '../create-trip-form/create-trip-form.model';
import { Trips } from '../trips';
import { DatePipe } from '@angular/common';
import { finalize, map, Subscription } from 'rxjs';
import { relative } from '@angular/compiler-cli';
import { EachTrip } from '../each-trip/each-trip';
import { CreateTripForm } from '../create-trip-form/create-trip-form';

@Component({
  imports: [RouterOutlet, RouterLink, DatePipe, EachTrip, CreateTripForm],
  selector: 'app-trip-details',
  styleUrl: './trip-details.css',
  templateUrl: './trip-details.html',
})
export class TripDetails {
  tripId = input.required<string>();

  private elementRef = inject(ElementRef);
  private router = inject(Router);
  private tripService = inject(Trips);
  private route = inject(ActivatedRoute);

  trip = signal<Trip | undefined>(undefined);
  daysArr = signal<string[]>([]);
  isFetching = signal<boolean>(false);

  getTripSubscription: Subscription;

  onGetTrip(tripId: string) {
    this.getTripSubscription?.unsubscribe();

    this.isFetching.set(true);
    this.getTripSubscription = this.tripService
      .getTrip(tripId)
      .pipe(
        finalize(() => {
          this.isFetching.set(false);
        }),
      )
      .subscribe({
        next: (res) => {
          this.trip.set(res);
          this.createEmptyArray(res.days);
        },
        error: (err) => {
          console.log(err);
        },
      });
  }

  createEmptyArray(length: number) {
    for (let i = 0; i < length; i++) {
      this.daysArr().push('');
    }
  }

  ngOnInit() {
    this.onGetTrip(this.tripId());
  }

  onEditTrip() {
    this.router.navigate(['edit-trip',this.tripId()]).then();
  }

  onDeleteTrip() {
    // this.tripService.deleteTrip(this.tripId()).pipe(finalize(() => {
    //   this.router.navigate(['trips']).then(() => console.log("Trip deleted successfully"));
    // })).subscribe();
  }

  ngOnDestroy() {
    this.getTripSubscription?.unsubscribe();
  }
}
