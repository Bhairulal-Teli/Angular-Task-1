import { Component, computed, effect, inject, input, signal, untracked } from '@angular/core';
import { Trips } from '../trips';
import { ActivatedRoute } from '@angular/router';
import { DayData } from '../create-trip-form/create-trip-form.model';
import { from, Observable, of, Subscription } from 'rxjs';

@Component({
  imports: [],
  selector: 'app-day-detail',
  styleUrl: './day-detail.css',
  templateUrl: './day-detail.html',
})
export class DayDetail {
  tripId = input.required<string>();
  day = input.required<string>();

  private currentRoute = inject(ActivatedRoute);
  private tripService = inject(Trips);

  dayNumber = computed(() => {
    return Number(this.day());
  });

  dayData = signal<DayData | undefined>(undefined);
  isFetchingDay = signal(false);

  getDayData: Subscription;
  constructor() {
    effect(() => {
      let selectedDay = Number(this.day());
      untracked(() => {
        this.getDayData?.unsubscribe();
        this.isFetchingDay.set(true);
        this.getDayData = this.tripService.getDay(this.tripId(), selectedDay).subscribe({
          next: (res) => {
            this.isFetchingDay.set(false);
            this.dayData.set(res);
          },
          error: (err) => {
            this.isFetchingDay.set(false);
            console.log(err);
          },
        });
      });
    });
  }

  ngOnDestroy() {
    this.getDayData?.unsubscribe();
  }
}
