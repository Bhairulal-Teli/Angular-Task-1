import { inject, Service } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DayData, Trip } from './create-trip-form/create-trip-form.model';
import { concat, filter, forkJoin, map, switchMap } from 'rxjs';

@Service()
export class Trips {
  private url = 'http://localhost:3000';
  private http = inject(HttpClient);

  addTrip(tripData: Trip, daysData: DayData[]) {
    return this.http.post<Trip>(this.url + '/trips', tripData).pipe(
      switchMap((res) => {
        // if(res.days !== 0) {
        const dayRequests = daysData.map((d: DayData) =>
          this.http.post<DayData>(this.url + '/daysData', { ...d, tripId: res.id }),
        );
        return forkJoin(dayRequests);
        // } else {
        //   return of(null);
        // }
      }),
    );
  }

  getAllTrips() {
    return this.http.get<Trip[]>(`${this.url}/trips`);
  }

  getTrip(id: string) {
    return this.http.get<Trip>(`${this.url}/trips/${id}`);
  }

  getDay(tripId: string, currDay: number) {
    return this.http.get<DayData[]>(`${this.url}/daysData`).pipe(
      map((days) => {
        return days.find((day) => day.tripId === tripId && day.day === currDay);
      }),
    );
  }

  getAllDays(tripId: string) {
    return this.http
      .get<DayData[]>(`${this.url}/daysData`)
      .pipe(map((days) => days.filter((day) => day.tripId === tripId)));
  }

  getTripAndDays(tripId: string) {
    return forkJoin({ trip: this.getTrip(tripId), days: this.getAllDays(tripId) });
  }

  // deleteTrip(id: string) {
  //   return this.http.delete<Trip>(`${this.url}/trips/${id}`).pipe(
  //     switchMap((res) => {
  //       const tripId = res.id;
  //       let daysToDelete= this.http.get<DayData[]>(`${this.url}/daysData`).pipe(map(value => {
  //         return value.filter((el) => el.tripId === tripId);
  //       }));
  //
  //
  //     }),
  //   );
  // }
}
