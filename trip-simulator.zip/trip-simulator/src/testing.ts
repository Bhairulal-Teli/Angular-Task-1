// const values = [1,2,3,4].forEach(val => {num: val});
//
// let values = {};
//
// for(let val of [1,2,3,4]) {
//   values = {...values, val}
// }
//
// console.log(values);

// const arr = [1, 2, 3, 4];
//
// let values = arr.map((val) => {
//   let obj = [
//     {
//       first: 'a',
//       second: 'b',
//     },
//     {
//       first: 'c',
//       second: 'd',
//     }
//   ];
//
//   return {...obj};
// });


const values = [
  [
    { first: 'a', second: 'b' },
    { first: 'c', second: 'd' },
  ],
  [
    { first: 'e', second: 'f' },
    { first: 'g', second: 'h' },
  ],
];

console.log(values.flat())
