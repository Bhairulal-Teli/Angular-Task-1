import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CreateTripForm } from '../components/create-trip-form/create-trip-form';
import { Navbar } from '../components/navbar/navbar';
import { DragAndDrop } from '../components/drag-and-drop/drag-and-drop';

@Component({
  imports: [RouterOutlet, Navbar, DragAndDrop],
  selector: 'app-root',
  styleUrl: './app.css',
  templateUrl: './app.html',
})
export class App {}
