import { Routes } from '@angular/router';
import { CreateTripForm } from '../components/create-trip-form/create-trip-form';
import { ViewTrips } from '../components/view-trips/view-trips';
import { TripDetails } from '../components/trip-details/trip-details';
import { DayDetail } from '../components/day-detail/day-detail';
import { dayGuard } from '../components/create-trip-form/day-guard-guard';
import { EditDetails } from '../components/edit-details/edit-details';

export const routes: Routes = [
  { path: '', component: ViewTrips },
  { path: 'create-trip', component: CreateTripForm },
  { path: 'edit-trip/:tripId', component: CreateTripForm },
  {
    path: 'view-trip/:tripId',
    component: TripDetails,
    children: [
      { path: '', redirectTo: '1', pathMatch: 'full' },
      { path: ':day', component: DayDetail, canActivate: [dayGuard] },
    ],
  },
];
